// © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
// Référence scientifique : Mghabbar & Ratnamogan (ECAI 2020)

import {
  CaseStudyResult,
  LibraryDocument,
  ProfessorConfig,
  QuizQuestion,
} from '../types/university';
import { buildDocumentFromOcrOrText } from '../utils/ragAndOcrEngine';

export const INITIAL_PROFESSORS: ProfessorConfig[] = [
  {
    id: 'medecine',
    nom_affiche: 'Dr Samir',
    titre: 'Professeur de Médecine & Santé',
    discipline_courte: 'Médecine & Santé',
    avatar_initials: 'DS',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Il t'explique le corps humain, la prévention et la santé avec des mots simples.",
    ton: 'Bienveillant, calme, rigoureux et rassurant',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/medecine/',
    modele_teacher: 'checkpoints/teacher_medical.pt',
    outils_autorises: ['rag_search', 'citation_verifier', 'emergency_guard'],
    avertissement:
      "Information éducative uniquement : ne remplace jamais une consultation ni un avis médical personnalisé. En cas d'urgence, appelez le 150 (Maroc) ou le 15 / 112.",
    sujets_hors_perimetre: ['droit', 'finance', 'programmation', 'fiscalite'],
    keywords: [
      'sante', 'medecine', 'medecin', 'corps', 'coeur', 'tension', 'hypertension',
      'diabete', 'glycemie', 'sommeil', 'nutrition', 'vaccin', 'clinique', 'patient',
      'symptome', 'prevention', 'oxygene', 'hemoglobine', 'respiration'
    ],
    system_prompt: `Tu es le Professeur de Médecine de l'Université Numérique. Réponds uniquement à partir de la bibliothèque fournie et cite toujours la source (document, page). Si la réponse n'y figure pas, dis « Je ne sais pas ». Adapte ton vocabulaire au niveau de l'apprenant. Ne pose jamais de diagnostic et ne prescris rien.`,
    yaml_raw: `id: medecine
nom_affiche: "Dr Samir"
titre: "Professeur de Médecine et Santé"
description_simple: "Il t'explique le corps humain et la santé avec des mots simples."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/medecine/
modele_teacher: checkpoints/teacher_medical.pt
system_prompt: |
  Tu es le Professeur de Médecine de l'Université Numérique.
  Réponds uniquement à partir de la bibliothèque fournie et cite toujours la source
  (document, page). Si la réponse n'y figure pas, dis « Je ne sais pas ».
sujets_hors_perimetre: [droit, finance, programmation]
avertissement: "Information éducative, ne remplace pas un avis médical."`,
  },
  {
    id: 'droit',
    nom_affiche: 'Maître Karim',
    titre: 'Professeur de Droit & Conformité',
    discipline_courte: 'Droit & Conformité',
    avatar_initials: 'MK',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Il t'aide à comprendre tes droits, les contrats et les lois du quotidien.",
    ton: 'Clair, méthodique, équitable et pédagogue',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/droit/',
    modele_teacher: 'checkpoints/teacher_legal.pt',
    outils_autorises: ['rag_search', 'citation_verifier'],
    avertissement:
      "Information juridique à caractère éducatif : ne constitue pas un acte de conseil juridique personnalisé d'avocat ou de notaire.",
    sujets_hors_perimetre: ['medecine', 'chimie', 'astrophysique'],
    keywords: [
      'droit', 'loi', 'contrat', 'travail', 'salarie', 'employeur', 'licenciement',
      'bail', 'locataire', 'proprietaire', 'conformite', 'rgpd', 'donnees', 'cnil',
      'cndp', 'clause', 'periode', 'essai', 'juridique', 'tribunal', 'code'
    ],
    system_prompt: `Tu es le Professeur de Droit & Conformité de l'Université Numérique. Cite systématiquement le document et la page de ta bibliothèque. Rappelle qu'il s'agit d'information éducative et oriente vers un professionnel du droit pour tout litige.`,
    yaml_raw: `id: droit
nom_affiche: "Maître Karim"
titre: "Professeur de Droit & Conformité"
description_simple: "Il t'aide à comprendre tes droits, les contrats et les lois du quotidien."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/droit/
modele_teacher: checkpoints/teacher_legal.pt
avertissement: "Information juridique éducative, ne remplace pas un avocat."`,
  },
  {
    id: 'finance',
    nom_affiche: 'Pr Nadia',
    titre: 'Professeure de Finance & Banque',
    discipline_courte: 'Finance & Banque',
    avatar_initials: 'PN',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Elle t'apprend à gérer un budget, comprendre l'épargne et les crédits.",
    ton: 'Pragmatique, transparent et structuré',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/finance/',
    modele_teacher: 'checkpoints/teacher_finance.pt',
    outils_autorises: ['rag_search', 'citation_verifier', 'calculator'],
    avertissement:
      "Information financière éducative : ne constitue ni un conseil en investissement financier ni une recommandation bancaire.",
    sujets_hors_perimetre: ['medecine', 'biologie', 'anatomie'],
    keywords: [
      'finance', 'banque', 'budget', 'epargne', 'credit', 'pret', 'taux', 'interet',
      'investissement', 'inflation', 'tresorerie', 'bilan', 'comptabilite', 'amortissement',
      'fiscalite', 'impot', 'facture', 'capital', 'rendement'
    ],
    system_prompt: `Tu es la Professeure de Finance & Banque. Tes explications s'appuient exclusivement sur ta bibliothèque avec citation du document et de la page. Rappelle toujours la prudence financière.`,
    yaml_raw: `id: finance
nom_affiche: "Pr Nadia"
titre: "Professeure de Finance & Banque"
description_simple: "Elle t'apprend à gérer un budget, comprendre l'épargne et les crédits."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/finance/
modele_teacher: checkpoints/teacher_finance.pt
avertissement: "Information éducative, ne constitue pas un conseil financier personnalisé."`,
  },
  {
    id: 'technologie',
    nom_affiche: 'Pr Yasmine',
    titre: 'Professeure de Technologie & Informatique',
    discipline_courte: 'Technologie & IA',
    avatar_initials: 'PY',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Elle démystifie les ordinateurs, la programmation, la cybersécurité et l'IA.",
    ton: 'Concret, encourageant et illustré',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/technologie/',
    modele_teacher: 'checkpoints/teacher_tech.pt',
    outils_autorises: ['rag_search', 'citation_verifier'],
    avertissement: '',
    sujets_hors_perimetre: ['medecine', 'chirurgie'],
    keywords: [
      'informatique', 'ordinateur', 'algorithme', 'code', 'python', 'securite',
      'mot de passe', 'phishing', 'reseau', 'internet', 'distillation', 'modele',
      'ia', 'intelligence artificielle', 'ocr', 'indra', 'onnx', 'serveur', 'logiciel'
    ],
    system_prompt: `Tu es la Professeure de Technologie & Informatique. Explique les concepts numériques pas à pas à partir de ta bibliothèque en citant la page exacte.`,
    yaml_raw: `id: technologie
nom_affiche: "Pr Yasmine"
titre: "Professeure de Technologie & Informatique"
description_simple: "Elle démystifie les ordinateurs, la programmation, la cybersécurité et l'IA."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/technologie/
modele_teacher: checkpoints/teacher_tech.pt`,
  },
  {
    id: 'mathematiques',
    nom_affiche: 'Pr Omar',
    titre: 'Professeur de Mathématiques',
    discipline_courte: 'Mathématiques',
    avatar_initials: 'PO',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Il rend le calcul, les pourcentages, la géométrie et les probabilités limpides.",
    ton: 'Patient, logique et progressif',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/mathematiques/',
    modele_teacher: 'checkpoints/teacher_math.pt',
    outils_autorises: ['rag_search', 'citation_verifier'],
    avertissement: '',
    sujets_hors_perimetre: ['droit', 'medecine'],
    keywords: [
      'math', 'mathematiques', 'calcul', 'pourcentage', 'fraction', 'proportion',
      'equation', 'geometrie', 'probabilite', 'statistique', 'moyenne', 'logique',
      'fonction', 'derivee', 'matrice', 'softmax', 'divergence'
    ],
    system_prompt: `Tu es le Professeur de Mathématiques. Utilise des exemples de la vie courante pour un débutant et cite toujours la page de ta bibliothèque.`,
    yaml_raw: `id: mathematiques
nom_affiche: "Pr Omar"
titre: "Professeur de Mathématiques"
description_simple: "Il rend le calcul, les pourcentages, la géométrie et les probabilités limpides."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/mathematiques/`,
  },
  {
    id: 'sciences',
    nom_affiche: 'Pr Leïla',
    titre: 'Professeure de Sciences (Physique, Chimie, Biologie)',
    discipline_courte: 'Sciences de la Nature',
    avatar_initials: 'PL',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Elle t'explique comment fonctionnent la nature, l'énergie, l'eau et les plantes.",
    ton: 'Curieux, expérimental et lumineux',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/sciences/',
    modele_teacher: 'checkpoints/teacher_science.pt',
    outils_autorises: ['rag_search', 'citation_verifier'],
    avertissement: '',
    sujets_hors_perimetre: ['fiscalite', 'droit'],
    keywords: [
      'science', 'physique', 'chimie', 'biologie', 'energie', 'plante', 'xyleme',
      'phloeme', 'atome', 'molecule', 'eau', 'climat', 'photosynthese', 'cellule',
      'electricite', 'thermodynamique'
    ],
    system_prompt: `Tu es la Professeure de Sciences. Appuie chaque explication sur ta bibliothèque avec citation du document et de la page.`,
    yaml_raw: `id: sciences
nom_affiche: "Pr Leïla"
titre: "Professeure de Sciences (Physique, Chimie, Biologie)"
description_simple: "Elle t'explique comment fonctionnent la nature, l'énergie, l'eau et les plantes."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/sciences/`,
  },
  {
    id: 'langues',
    nom_affiche: 'Pr Hugo',
    titre: 'Professeur de Langues & Traduction',
    discipline_courte: 'Langues & Traduction',
    avatar_initials: 'PH',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Il t'aide à rédiger clairement, améliorer ton style et traduire sans faux-sens.",
    ton: 'Éloquent, attentif et nuancé',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/langues/',
    modele_teacher: 'checkpoints/teacher_translation.pt',
    outils_autorises: ['rag_search', 'citation_verifier'],
    avertissement: '',
    sujets_hors_perimetre: ['chirurgie', 'comptabilite'],
    keywords: [
      'langue', 'traduction', 'traduire', 'francais', 'arabe', 'anglais', 'grammaire',
      'orthographe', 'redaction', 'lettre', 'vocabulaire', 'terminologie', 'bilingue',
      'nmt', 'bleu', 'corpus'
    ],
    system_prompt: `Tu es le Professeur de Langues & Traduction. Cite les guides linguistiques et glossaires de ta bibliothèque avec le numéro de page.`,
    yaml_raw: `id: langues
nom_affiche: "Pr Hugo"
titre: "Professeur de Langues & Traduction"
description_simple: "Il t'aide à rédiger clairement, améliorer ton style et traduire sans faux-sens."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/langues/`,
  },
  {
    id: 'histoire_geo',
    nom_affiche: 'Pr Rachid',
    titre: 'Professeur d’Histoire & Géographie',
    discipline_courte: 'Histoire-Géographie',
    avatar_initials: 'PR',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Il raconte les civilisations, les cartes et l'évolution du monde.",
    ton: 'Narratif, rigoureux et contextualisé',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/histoire_geo/',
    modele_teacher: 'checkpoints/teacher_history.pt',
    outils_autorises: ['rag_search', 'citation_verifier'],
    avertissement: '',
    sujets_hors_perimetre: ['programmation', 'pharmacologie'],
    keywords: [
      'histoire', 'geographie', 'civilisation', 'maroc', 'mediterranee', 'europe',
      'afrique', 'carte', 'territoire', 'demographie', 'patrimoine', 'universite',
      'al quaraouiyine', 'siecle', 'chronologie'
    ],
    system_prompt: `Tu es le Professeur d'Histoire-Géographie. Cite toujours les ouvrages historiques et atlas de ta bibliothèque avec le numéro de page.`,
    yaml_raw: `id: histoire_geo
nom_affiche: "Pr Rachid"
titre: "Professeur d'Histoire & Géographie"
description_simple: "Il raconte les civilisations, les cartes et l'évolution du monde."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/histoire_geo/`,
  },
  {
    id: 'economie',
    nom_affiche: 'Pr Claire',
    titre: 'Professeure d’Économie & Gestion',
    discipline_courte: 'Économie & Gestion',
    avatar_initials: 'PC',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Elle t'aide à organiser un projet, créer une activité et comprendre les marchés.",
    ton: 'Stratégique, concret et accessible',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/economie/',
    modele_teacher: 'checkpoints/teacher_management.pt',
    outils_autorises: ['rag_search', 'citation_verifier'],
    avertissement: '',
    sujets_hors_perimetre: ['medecine'],
    keywords: [
      'economie', 'gestion', 'entreprise', 'projet', 'client', 'marche', 'offre',
      'demande', 'organisation', 'cooperative', 'auto-entrepreneur', 'statut',
      'fournisseur', 'strategie', 'rh', 'ressources humaines'
    ],
    system_prompt: `Tu es la Professeure d'Économie & Gestion. Réponds à partir des manuels de gestion de ta bibliothèque en citant la page.`,
    yaml_raw: `id: economie
nom_affiche: "Pr Claire"
titre: "Professeure d'Économie & Gestion"
description_simple: "Elle t'aide à organiser un projet, créer une activité et comprendre les marchés."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/economie/`,
  },
  {
    id: 'civique',
    nom_affiche: 'Pr Amina',
    titre: 'Professeure d’Éducation Civique & Vie Pratique',
    discipline_courte: 'Vie Pratique & Civisme',
    avatar_initials: 'PA',
    langues: ['fr', 'ar', 'en'],
    description_simple: "Elle t'accompagne dans les démarches administratives, la citoyenneté et le quotidien.",
    ton: 'Chaleureux, patient et très pratique',
    niveau_par_defaut: 'debutant',
    bibliotheque: 'libraries/civique/',
    modele_teacher: 'checkpoints/teacher_civic.pt',
    outils_autorises: ['rag_search', 'citation_verifier'],
    avertissement: '',
    sujets_hors_perimetre: ['astrophysique'],
    keywords: [
      'civique', 'citoyen', 'administration', 'demarches', 'mairie', 'consommation',
      'facture', 'reclamation', 'courrier', 'voisinage', 'association', 'famille',
      'retraite', 'accessibilite', 'senior', 'securite routiere'
    ],
    system_prompt: `Tu es la Professeure d'Éducation Civique & Vie Pratique. Explique chaque démarche simplement à partir de ta bibliothèque en citant la page.`,
    yaml_raw: `id: civique
nom_affiche: "Pr Amina"
titre: "Professeure d'Éducation Civique & Vie Pratique"
description_simple: "Elle t'accompagne dans les démarches administratives, la citoyenneté et le quotidien."
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/civique/`,
  },
];

export function buildInitialLibraries(): LibraryDocument[] {
  return [
    buildDocumentFromOcrOrText({
      professorId: 'medecine',
      title: 'Guide Pratique de Prévention Cardiovasculaire et Physiologie Humaine',
      authorOrSource: 'Bibliothèque Universitaire Santé — Édition 2026',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
La tension artérielle mesure la pression exercée par le sang sur la paroi des artères. Une tension normale au repos se situe généralement autour de 120/80 mmHg chez l'adulte. L'hypertension artérielle correspond à une pression durablement élevée (souvent supérieure ou égale à 140/90 mmHg au cabinet médical) et nécessite un suivi régulier par un médecin.

[Page 2]
Le transport de l'oxygène dans le sang repose sur l'hémoglobine contenue dans les globules rouges. L'effet Bohr décrit comment une augmentation du dioxyde de carbone (CO2) et une baisse du pH dans les muscles actifs facilitent la libération de l'oxygène par l'hémoglobine exactement là où les tissus en ont besoin.

[Page 3]
Hygiène de vie et sommeil : Chez l'adolescent comme chez le senior, un sommeil régulier de 7 à 8 heures par nuit, une marche quotidienne de 30 minutes et une réduction de la consommation de sel (moins de 5 g par jour selon l'OMS) contribuent directement à protéger le cœur et la mémoire. Pour tout exercice médical en clinique ou cabinet, le médecin salarié ou libéral doit respecter le code de déontologie médicale et l'indépendance professionnelle de ses décisions de soins.`,
    }),
    buildDocumentFromOcrOrText({
      professorId: 'droit',
      title: 'Manuel Fondamental du Droit du Travail, des Contrats et de la Protection des Données',
      authorOrSource: 'Collection Droit & Citoyenneté — Édition 2026',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
Le contrat de travail écrit précise l'identité des parties, la qualification professionnelle, la rémunération brute, le lieu de travail et la durée de la période d'essai. Dans le cas particulier du contrat de travail d'un médecin salarié (clinique, centre de santé ou médecine du travail), une clause fondamentale garantit l'indépendance technique et déontologique du praticien ainsi que le respect absolu du secret médical vis-à-vis de l'employeur administratif.

[Page 2]
Le bail d'habitation lie le propriétaire (bailleur) et le locataire. Un état des lieux contradictoire doit être signé à l'entrée et à la sortie du logement. Le dépôt de garantie ne peut excéder le plafond légal et doit être restitué après déduction des seules réparations locatives justifiées par factures.

[Page 3]
Protection des données personnelles (RGPD en Europe et Loi 09-08 au Maroc contrôlée par la CNDP) : Toute collecte de données personnelles exige un consentement libre et éclairé, une finalité déterminée, et garantit à chaque citoyen un droit d'accès, de rectification, de portabilité et de suppression en un clic.`,
    }),
    buildDocumentFromOcrOrText({
      professorId: 'finance',
      title: 'Traité de Gestion Budgétaire, Crédit Bancaire et Fiscalité Pratique',
      authorOrSource: 'Institut de Finance Pédagogique — 2026',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
Règle d'équilibre budgétaire familial et professionnel : La méthode 50/30/20 consiste à répartir ses revenus nets mensuels entre 50 % pour les charges fixes essentielles (logement, alimentation, santé), 30 % pour les dépenses personnelles et 20 % pour l'épargne de précaution ou le remboursement anticipé de dettes.

[Page 2]
Comprendre un crédit bancaire : Le Taux Annuel Effectif Global (TAEG / TEG) inclut non seulement le taux d'intérêt nominal mais aussi les frais de dossier et le coût de l'assurance emprunteur obligatoire. Avant de signer un prêt, vérifiez que la mensualité totale ne dépasse pas 33 % de vos revenus nets réguliers.

[Page 3]
Fiscalité et trésorerie d'une activité médicale ou de services : Lorsqu'un professionnel de santé ou un entrepreneur démarre son activité, il doit séparer son compte bancaire personnel de son compte professionnel, provisionner environ 25 à 30 % de son excédent brut pour les cotisations sociales et impôts, et établir un plan de trésorerie prévisionnel sur 12 mois.`,
    }),
    buildDocumentFromOcrOrText({
      professorId: 'technologie',
      title: 'Architecture de Distillation Multi-Professeurs (ECAI 2020) et Moteur Indra OCR Local',
      authorOrSource: 'Tarik Badri & Larbi Badri — Référence Mghabbar & Ratnamogan (ECAI 2020)',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
Principe de la Distillation de Connaissances Multi-Professeurs (ECAI 2020, Mghabbar & Ratnamogan) : Au lieu de déployer plusieurs modèles lourds spécialisés en production, chaque modèle Professeur (Teacher) spécialisé sur un domaine (Finance, Droit, Médecine, Technologie) transfère sa distribution de probabilités adoucie par une température T vers un unique modèle Étudiant (Student) polyvalent. La fonction de perte combine l'entropie croisée lissée (Label Smoothing) et la divergence de Kullback-Leibler : L = (1 - alpha) * CE_smooth + alpha * T^2 * KL.

[Page 2]
Lecture documentaire par Indra OCR sur CPU (ONNX Runtime) : Le pipeline OCR analyse d'abord si le fichier PDF possède une couche texte native. Si des zones scannées, inclinées ou manuscrites sont détectées, le modèle léger (~1 million de paramètres) reconstruit la mise en page (titres, listes, tableaux, numéros de page) en Markdown structuré en environ 210 ms par page sur un processeur 4 cœurs standard, sans nécessiter de carte graphique (GPU).

[Page 3]
Hygiène de cybersécurité quotidienne : Un mot de passe robuste contient au moins 12 caractères variés ou une phrase de passe mémorisable. Ne cliquez jamais sur un lien demandant vos identifiants bancaires par SMS ou courriel (hameçonnage / phishing), et conservez vos documents sensibles chiffrés ou stockés localement.`,
    }),
    buildDocumentFromOcrOrText({
      professorId: 'mathematiques',
      title: 'Les Mathématiques Utiles : Proportions, Pourcentages et Probabilités',
      authorOrSource: 'Département de Mathématiques Appliquées — 2026',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
Calculer une évolution en pourcentage : Appliquer une remise de 20 % revient à multiplier le prix initial par 0,80. Attention au piège classique : une hausse de 20 % suivie d'une baisse de 20 % ne ramène pas au prix de départ, car 1,20 x 0,80 = 0,96, soit une baisse finale de 4 %.

[Page 2]
Probabilités et lecture critique des statistiques : La moyenne arithmétique peut être déformée par quelques valeurs extrêmes. La médiane partage une population en deux groupes égaux de 50 % et donne souvent une vision beaucoup plus fidèle de la réalité quotidienne.`,
    }),
    buildDocumentFromOcrOrText({
      professorId: 'sciences',
      title: 'Systèmes Vivants, Transport Vasculaire des Plantes et Énergie',
      authorOrSource: 'Faculté des Sciences de la Nature — 2026',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
Circulation dans les plantes (Xylème et Phloème) : Le xylème transporte l'eau et les sels minéraux (sève brute) des racines vers les feuilles grâce à la transpiration foliaire et à la cohésion des molécules d'eau. Le phloème distribue les sucres produits par la photosynthèse (sève élaborée) des feuilles vers les organes de réserve et les bourgeons.

[Page 2]
Conservation de l'énergie et puissance électrique : L'énergie consommée par un appareil électrique (en kilowattheures, kWh) est égale à sa puissance (en kW) multipliée par sa durée d'utilisation (en heures). Un radiateur de 2000 W (2 kW) allumé pendant 3 heures consomme exactement 6 kWh.`,
    }),
    buildDocumentFromOcrOrText({
      professorId: 'langues',
      title: 'Guide de Rédaction Claire et Traduction Spécialisée Multi-Domaines',
      authorOrSource: 'École de Traduction et Communication — 2026',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
Principes de la communication claire (Plain Language) : Privilégiez une seule idée par phrase, utilisez la voix active plutôt que la voix passive, et expliquez systématiquement tout acronyme dès sa première apparition.

[Page 2]
Traduction spécialisée et polysémie : Un même mot change radicalement de traduction selon le domaine. En anglais, le terme « equity » signifie « capitaux propres » en Finance, mais « équité / justice » en Droit. C'est pourquoi la distillation multi-professeurs adapte la traduction au contexte disciplinaire.`,
    }),
    buildDocumentFromOcrOrText({
      professorId: 'histoire_geo',
      title: 'Histoire de la Transmission du Savoir et Géographie des Ressources',
      authorOrSource: 'Chaire Histoire & Civilisations — 2026',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
Des grandes bibliothèques historiques à l'Université Numérique : Fondée à Fès au IXe siècle par Fatima al-Fihriya, l'université Al Quaraouiyine illustre une tradition millénaire où astronomie, médecine, droit, mathématiques et lettres dialoguent au sein d'un même lieu d'étude ouvert aux chercheurs.

[Page 2]
Géographie de l'eau et adaptation climatique : Dans le bassin méditerranéen et en Afrique du Nord, la gestion durable des nappes phréatiques, des barrages et du dessalement alimenté par l'énergie solaire constitue l'enjeu territorial majeur du XXIe siècle.`,
    }),
    buildDocumentFromOcrOrText({
      professorId: 'economie',
      title: 'Créer et Piloter une Entreprise ou Coopérative : De l’Idée au Plan d’Action',
      authorOrSource: 'Institut d’Économie & Gestion — 2026',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
Les 4 piliers d'un projet entrepreneurial viable : 1) Répondre à un besoin réel et vérifié sur le terrain ; 2) Choisir une structure juridique adaptée (auto-entrepreneur, SARL, coopérative) ; 3) Calculer son seuil de rentabilité (chiffre d'affaires minimum couvrant les charges fixes et variables) ; 4) Assurer la qualité du service et la conformité réglementaire.

[Page 2]
Organisation du travail et prévention des risques : Toute structure accueillant du public ou des salariés doit documenter ses procédures d'accueil, former son équipe et tenir à jour ses registres obligatoires.`,
    }),
    buildDocumentFromOcrOrText({
      professorId: 'civique',
      title: 'Guide Pratique des Démarches Administratives et de la Solidarité Intergénérationnelle',
      authorOrSource: 'Maison du Citoyen — Édition 2026',
      sourceType: 'native_pdf',
      rawText: `[Page 1]
Rédiger une réclamation ou un courrier administratif efficace : Indiquez toujours en haut à gauche vos coordonnées et votre numéro de dossier ou de contrat, exposez les faits par ordre chronologique avec les dates exactes, joignez la copie (jamais l'original) des justificatifs, et conservez une preuve d'envoi.

[Page 2]
Inclusion numérique de 15 à 80+ ans : Tout service numérique citoyen doit proposer des caractères lisibles d'au moins 18 à 20 pixels, un contraste élevé, une lecture vocale intégrée et zéro jargon informatique pour garantir l'autonomie de chaque génération.`,
    }),
  ];
}

export interface SampleDocumentPreset {
  id: string;
  title: string;
  targetProfessorId: string;
  sourceType: LibraryDocument['sourceType'];
  authorOrSource: string;
  description: string;
  rawText: string;
}

export const SAMPLE_PROFESSIONAL_DOCUMENTS_FOR_AGENTS: SampleDocumentPreset[] = [
  {
    id: 'preset_clinique_telemedecine',
    title: 'Protocole Professionnel : Téléconsultation Médicale & Secret Partagé (2026)',
    targetProfessorId: 'medecine',
    sourceType: 'native_pdf',
    authorOrSource: 'Ordre & Collège de Santé Numérique — Guide Praticien',
    description:
      'Enrichit Dr Samir avec les règles professionnelles de télémédecine, d’authentification forte et de compte-rendu médical.',
    rawText: `[Page 1]
Conditions d'exercice de la téléconsultation médicale : Toute téléconsultation nécessite le consentement libre et éclairé du patient après vérification de son identité. Le praticien doit s'assurer que la qualité vidéo et sonore permet un interrogatoire clinique fiable. Si un examen physique direct est indispensable, le médecin interrompt la téléconsultation et oriente le patient vers une consultation présentielle.

[Page 2]
Traçabilité et compte-rendu dans le dossier médical : À l'issue de chaque téléconsultation, le médecin rédige un compte-rendu daté mentionnant les motifs, les constatations cliniques, les conseils d'éducation thérapeutique et les modalités de suivi. Les données de santé doivent être hébergées sur une infrastructure certifiée ou conservées en local chiffré.`,
  },
  {
    id: 'preset_audit_contrats_ia',
    title: 'Référentiel Juridique : Clauses de Sous-Traitance, Propriété Intellectuelle & Conformité',
    targetProfessorId: 'droit',
    sourceType: 'ocr_scan',
    authorOrSource: 'Cabinet de Conformité & Droit des Affaires — 2026',
    description:
      'Rend Maître Karim expert sur les clauses de confidentialité (NDA), la propriété du code logiciel et les pénalités de retard.',
    rawText: `[Page 1]
Propriété intellectuelle d'un logiciel créé sur commande : En droit d'auteur, le simple paiement d'une facture de prestation ne transfère pas automatiquement les droits patrimoniaux sur le code source. Le contrat de cession doit obligatoirement énumérer par écrit chaque droit cédé (reproduction, adaptation, distribution), le territoire, la durée et le prix correspondant.

[Page 2]
Clause de confidentialité (NDA) et sous-traitance : Le prestataire s'engage à ne divulguer aucune information technique, commerciale ou financière reçue du client pendant toute la durée du contrat et durant 5 ans après son terme. Toute sous-traitance requiert l'accord écrit préalable du client et impose au sous-traitant les mêmes garanties de sécurité.`,
  },
  {
    id: 'preset_analyse_bilan_pme',
    title: 'Manuel Expert : Diagnostic Financier, BFR et Flux de Trésorerie des PME',
    targetProfessorId: 'finance',
    sourceType: 'native_pdf',
    authorOrSource: 'Chambre Fiduciaire & Analyse Financière — 2026',
    description:
      'Forme Pr Nadia au calcul précis du Besoin en Fonds de Roulement (BFR), de la Capacité d’Autofinancement (CAF) et des délais de paiement.',
    rawText: `[Page 1]
Maîtrise du Besoin en Fonds de Roulement (BFR) : Le BFR résulte du décalage temporel entre les décaissements (paiement des fournisseurs et des stocks) et les encaissements (règlement des factures par les clients). La formule fondamentale est : BFR = Stocks moyens + Créances clients - Dettes fournisseurs. Une entreprise rentable sur le papier peut faire défaut si son BFR explose sans trésorerie disponible.

[Page 2]
Capacité d'Autofinancement (CAF) et négociation des délais : Pour sécuriser sa trésorerie, l'entreprise doit facturer un acompte de 30 % à la commande, suivre chaque semaine la balance âgée des clients en retard, et maintenir un Fonds de Roulement Net Global (FRNG) supérieur à son BFR d'exploitation.`,
  },
  {
    id: 'preset_architecture_rag_local',
    title: 'Spécification Ingénieur : Déploiement RAG Hybride, ONNX Int8 & Sécurité Anti-Injection',
    targetProfessorId: 'technologie',
    sourceType: 'markdown_upload',
    authorOrSource: 'Laboratoire NeuroDistill — Tarik Badri & Larbi Badri',
    description:
      'Forme Pr Yasmine sur la quantification ONNX int8 sur CPU, le découpage avec chevauchement (chunk overlap) et la défense contre les injections.',
    rawText: `[Page 1]
Optimisation ONNX Runtime et Quantification Int8 sur CPU : L'export du modèle Étudiant distillé au format ONNX suivi d'une quantification dynamique Int8 réduit l'empreinte mémoire de 72 % et divise par 3,1 la latence d'inférence sur processeur 4 cœurs standard, tout en préservant plus de 99,2 % de la qualité de traduction et de routage.

[Page 2]
Défense contre l'injection de prompt indirecte (Indirect Prompt Injection) : Lorsqu'un agent IA lit un PDF externe via OCR, un document malveillant pourrait contenir des phrases cachées tentant de détourner le system_prompt. Le pipeline NeuroDistill isole systématiquement les extraits documentaires dans des balises de données passives et neutralise toute directive impérative avant l'indexation vectorielle.`,
  },
];

export const PREBUILT_CASE_STUDIES: CaseStudyResult[] = [
  {
    id: 'case_clinique_locale',
    scenarioTitle: 'Ouvrir un cabinet ou une petite structure de santé de proximité',
    userDescription:
      "Je souhaite créer un centre de prévention et de soins de proximité avec deux médecins salariés et un service de prise de rendez-vous numérique.",
    measuredLatencyMs: 3.4,
    transdisciplinarySummary:
      "L'Orchestrateur a mobilisé 4 professeurs (Médecine, Droit, Finance et Technologie) pour articuler la conformité déontologique, les contrats des praticiens, le plan de trésorerie et la protection des données de santé.",
    steps: [
      {
        stepNumber: 1,
        discipline: 'Droit & Conformité',
        professorId: 'droit',
        professorName: 'Maître Karim',
        subQuestion: 'Quelles clauses insérer dans le contrat de travail des médecins et pour les données ?',
        actionableAdvice:
          "Rédiger un contrat de travail écrit garantissant explicitement l'indépendance professionnelle du médecin et le secret médical, et déclarer le traitement des dossiers patients conformément au RGPD / Loi 09-08 (CNDP).",
        sourceCitation: 'Manuel Fondamental du Droit du Travail, des Contrats et de la Protection des Données · Pages 1 & 3',
      },
      {
        stepNumber: 2,
        discipline: 'Finance & Banque',
        professorId: 'finance',
        professorName: 'Pr Nadia',
        subQuestion: 'Comment structurer le budget de démarrage et la trésorerie ?',
        actionableAdvice:
          "Ouvrir un compte bancaire professionnel dédié, limiter les remboursements d'emprunt d'équipement sous le seuil de prudence et provisionner 25 à 30 % des excédents pour les charges sociales et fiscales sur un plan de trésorerie à 12 mois.",
        sourceCitation: 'Traité de Gestion Budgétaire, Crédit Bancaire et Fiscalité Pratique · Pages 2 & 3',
      },
      {
        stepNumber: 3,
        discipline: 'Médecine & Santé',
        professorId: 'medecine',
        professorName: 'Dr Samir',
        subQuestion: 'Quels protocoles de prévention et de suivi mettre en place ?',
        actionableAdvice:
          "Structurer les parcours d'éducation thérapeutique (suivi tensionnel 120/80 mmHg, hygiène de vie) et garantir que chaque acte reste sous la responsabilité médicale directe d'un praticien diplômé.",
        sourceCitation: 'Guide Pratique de Prévention Cardiovasculaire et Physiologie Humaine · Pages 1 & 3',
      },
      {
        stepNumber: 4,
        discipline: 'Technologie & Informatique',
        professorId: 'technologie',
        professorName: 'Pr Yasmine',
        subQuestion: 'Comment sécuriser les documents médicaux numérisés par OCR ?',
        actionableAdvice:
          "Traiter la numérisation des dossiers papier en local sur CPU via Indra OCR sans transfert vers des serveurs tiers non autorisés, avec mots de passe robustes de 12+ caractères.",
        sourceCitation: 'Architecture de Distillation Multi-Professeurs (ECAI 2020) et Moteur Indra OCR Local · Pages 2 & 3',
      },
    ],
  },
  {
    id: 'case_budget_logement_famille',
    scenarioTitle: 'Signer un premier bail de location et équilibrer son budget mensuel',
    userDescription:
      "J'ai 22 ans (ou j'accompagne mon petit-fils), je signe mon premier contrat de location et mon premier contrat de travail. Comment éviter les pièges ?",
    measuredLatencyMs: 2.8,
    transdisciplinarySummary:
      "L'Orchestrateur a réuni Maître Karim (Droit), Pr Nadia (Finance) et Pr Amina (Vie Pratique) pour sécuriser la signature du bail, vérifier le contrat de travail et construire un budget durable.",
    steps: [
      {
        stepNumber: 1,
        discipline: 'Droit & Conformité',
        professorId: 'droit',
        professorName: 'Maître Karim',
        subQuestion: 'Que vérifier avant de signer le bail et le contrat de travail ?',
        actionableAdvice:
          "Vérifier la durée de la période d'essai et la rémunération brute sur le contrat de travail ; exiger un état des lieux contradictoire écrit à l'entrée dans le logement.",
        sourceCitation: 'Manuel Fondamental du Droit du Travail, des Contrats et de la Protection des Données · Pages 1 & 2',
      },
      {
        stepNumber: 2,
        discipline: 'Finance & Banque',
        professorId: 'finance',
        professorName: 'Pr Nadia',
        subQuestion: 'Quelle part du salaire consacrer au loyer et à l’épargne ?',
        actionableAdvice:
          "Appliquer la règle 50/30/20 : 50 % maximum pour l'ensemble des charges fixes (loyer + factures + alimentation), 30 % pour la vie courante et 20 % mis de côté dès le début du mois en épargne de sécurité.",
        sourceCitation: 'Traité de Gestion Budgétaire, Crédit Bancaire et Fiscalité Pratique · Page 1',
      },
      {
        stepNumber: 3,
        discipline: 'Vie Pratique & Civisme',
        professorId: 'civique',
        professorName: 'Pr Amina',
        subQuestion: 'Comment classer ses justificatifs et rédiger ses courriers ?',
        actionableAdvice:
          "Conserver une copie numérique et papier de l'état des lieux et des quittances, et toujours mentionner son numéro de dossier par ordre chronologique dans tout courrier officiel.",
        sourceCitation: 'Guide Pratique des Démarches Administratives et de la Solidarité Intergénérationnelle · Page 1',
      },
    ],
  },
];

export const INITIAL_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q_distill_1',
    professorId: 'technologie',
    professorName: 'Pr Yasmine',
    question:
      "Dans l'architecture de distillation multi-professeurs (ECAI 2020), quel est le rôle du modèle Étudiant (Student Model) ?",
    options: [
      "Fusionner le savoir de plusieurs modèles Professeurs spécialisés en un seul modèle léger et rapide sans surcoût d'inférence.",
      "Remplacer les enseignants humains par un serveur nécessitant obligatoirement 8 cartes graphiques.",
      "Inventer des réponses sans consulter les bibliothèques documentaires.",
    ],
    correctIndex: 0,
    explanation:
      "Le modèle Étudiant apprend à partir des probabilités adoucies (soft targets) des Professeurs spécialisés via la perte combinant CE lissée et divergence KL.",
    sourceCitation: 'Architecture de Distillation Multi-Professeurs (ECAI 2020) et Moteur Indra OCR Local · Page 1',
  },
  {
    id: 'q_droit_1',
    professorId: 'droit',
    professorName: 'Maître Karim',
    question:
      "Quelle garantie essentielle doit figurer dans le contrat de travail d'un médecin salarié ?",
    options: [
      "L'obligation de communiquer le diagnostic privé des patients au service comptable.",
      "L'indépendance technique et déontologique du médecin ainsi que le respect du secret médical.",
      "L'absence totale de contrat écrit.",
    ],
    correctIndex: 1,
    explanation:
      "Même salarié, un médecin conserve son indépendance professionnelle pour ses décisions de soins et est tenu au secret médical absolu.",
    sourceCitation: 'Manuel Fondamental du Droit du Travail, des Contrats et de la Protection des Données · Page 1',
  },
  {
    id: 'q_finance_1',
    professorId: 'finance',
    professorName: 'Pr Nadia',
    question:
      "Que représente le TAEG (Taux Annuel Effectif Global) lors de la souscription d'un crédit bancaire ?",
    options: [
      "Uniquement le montant des frais de tenue de compte courant.",
      "Le coût complet du crédit incluant le taux nominal, les frais de dossier et l'assurance obligatoire.",
      "Le taux d'imposition sur le revenu.",
    ],
    correctIndex: 1,
    explanation:
      "Le TAEG permet de comparer honnêtement deux offres de prêt car il intègre tous les coûts obligatoires liés au crédit.",
    sourceCitation: 'Traité de Gestion Budgétaire, Crédit Bancaire et Fiscalité Pratique · Page 2',
  },
  {
    id: 'q_med_1',
    professorId: 'medecine',
    professorName: 'Dr Samir',
    question:
      "Comment l'effet Bohr aide-t-il les muscles en plein effort physique ?",
    options: [
      "Il bloque la circulation sanguine pendant l'effort.",
      "La hausse du CO2 et la baisse du pH dans le muscle actif facilitent la libération de l'oxygène par l'hémoglobine.",
      "Il transforme directement l'azote de l'air en glucose.",
    ],
    correctIndex: 1,
    explanation:
      "L'affinité de l'hémoglobine pour l'oxygène diminue lorsque le milieu devient plus acide et riche en CO2, ce qui libère l'oxygène là où les cellules travaillent.",
    sourceCitation: 'Guide Pratique de Prévention Cardiovasculaire et Physiologie Humaine · Page 2',
  },
];
