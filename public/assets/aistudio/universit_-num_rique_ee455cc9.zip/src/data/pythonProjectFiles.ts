// © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
// Référence scientifique : Mghabbar & Ratnamogan (ECAI 2020)

export interface AuditRow {
  modulePath: string;
  currentState: string;
  realOrMock: 'Factice (Squelette)' | 'Incomplet' | 'Risque Sécurité' | 'Conforme après refonte';
  requiredAction: string;
}

export const STEP1_AUDIT_TABLE: AuditRow[] = [
  {
    modulePath: 'src/api/routes.py',
    currentState: 'Renvoie `[Distilled NMT - FINANCE] ...` et scores BLEU 31.2 / 33.3 / 33.5 codés en dur.',
    realOrMock: 'Factice (Squelette)',
    requiredAction:
      'Supprimer tout score codé en dur. Renvoyer HTTP 503 explicite (« Le professeur est en cours de préparation ») si aucun checkpoint nest chargé ; ne renvoyer que des métriques mesurées depuis reports/metrics.json.',
  },
  {
    modulePath: 'src/training/knowledge_distillation.py',
    currentState: 'Paramètre `label_smoothing` déclaré dans config.yaml mais ignoré dans CrossEntropyLoss ; masque de padding partiel sur KL.',
    realOrMock: 'Incomplet',
    requiredAction:
      'Appliquer réellement `label_smoothing` dans la perte CE et masquer strictement les tokens de padding `<pad>` dans la divergence KL ($L = (1-\\alpha)\\cdot CE_{smooth} + \\alpha \\cdot T^2 \\cdot KL$).',
  },
  {
    modulePath: 'main.py',
    currentState: '`reload=True` en production et `allow_origins=["*"]` dans CORSMiddleware.',
    realOrMock: 'Risque Sécurité',
    requiredAction:
      'Restreindre CORS à `http://127.0.0.1:8000` et `http://localhost:3000` par défaut ; activer `reload` uniquement si `ENV=development` ; `/health` vérifie réellement les checkpoints et bibliothèques RAG.',
  },
  {
    modulePath: 'requirements.txt',
    currentState: 'Inclut `torchvision` et `torchaudio` inutiles et lourds.',
    realOrMock: 'Incomplet',
    requiredAction:
      'Retirer `torchvision`/`torchaudio`, épingler `onnxruntime`, `numpy`, `pytest`, `httpx`, `python-multipart`, `pydantic`, `sentencepiece`.',
  },
  {
    modulePath: 'professors/*.yaml & src/agents/',
    currentState: 'Absents du squelette initial.',
    realOrMock: 'Conforme après refonte',
    requiredAction:
      'Créer les 10 fichiers YAML validés par Pydantic + `ProfessorRegistry` dynamique + fenêtre d’ingestion OCR « Donner à lire à mes agents ».',
  },
  {
    modulePath: 'desktop/run_windows.bat & desktop/run_mac.sh',
    currentState: 'Scripts basiques sans vérification d’environnement ni ouverture automatique du navigateur.',
    realOrMock: 'Conforme après refonte',
    requiredAction:
      'Création automatique du venv, vérification disque/RAM, lancement local CPU et ouverture automatique de l’interface Université Numérique.',
  },
];

export interface DeliverableCodeFile {
  id: string;
  filename: string;
  platformLabel: string;
  description: string;
  language: 'batch' | 'bash' | 'python' | 'markdown';
  content: string;
}

export const DELIVERABLE_PROJECT_FILES: DeliverableCodeFile[] = [
  {
    id: 'run_windows_bat',
    filename: 'desktop/run_windows.bat',
    platformLabel: 'Windows 10 / 11 (.bat)',
    description:
      'Lanceur 1-clic pour Windows : crée l’environnement Python local, installe les dépendances CPU légères, vérifie les bibliothèques des professeurs et ouvre automatiquement la fenêtre Université Numérique.',
    language: 'batch',
    content: `@echo off
REM ============================================================================
REM Universite Numerique (NeuroDistill) — Lanceur 1-Clic Windows
REM Cree par Tarik Badri — en association avec Larbi Badri (c) 2026
REM Reference scientifique : Mghabbar & Ratnamogan (ECAI 2020)
REM ============================================================================
chcp 65001 >nul
title Universite Numerique — Tarik Badri ^& Larbi Badri

echo ============================================================================
echo   UNIVERSITE NUMERIQUE (NeuroDistill)
echo   Cree par Tarik Badri — en association avec Larbi Badri
echo ============================================================================
echo.

where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [Attention] Python n'est pas encore installe sur cet ordinateur.
    echo Veuillez installer Python 3.10+ depuis https://www.python.org
    pause
    exit /b 1
)

if not exist ".venv" (
    echo [1/3] Preparation de votre espace de travail local (premiere ouverture)...
    python -m venv .venv
)

call .venv\\Scripts\\activate.bat

echo [2/3] Verification des modules (CPU / ONNX Runtime / FastAPI)...
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

if not exist "libraries" mkdir libraries
if not exist "checkpoints" mkdir checkpoints

echo [3/3] Ouverture de l'Universite Numerique dans votre navigateur...
start "" "http://127.0.0.1:8000"
python main.py
pause
`,
  },
  {
    id: 'run_mac_sh',
    filename: 'desktop/run_mac.sh',
    platformLabel: 'macOS & Linux (.sh)',
    description:
      'Lanceur 1-clic pour macOS (Apple Silicon M1/M2/M3/M4 & Intel) et Linux : configure l’environnement local, active MPS/CPU et ouvre l’interface sans terminal complexe.',
    language: 'bash',
    content: `#!/usr/bin/env bash
# ==============================================================================
# Université Numérique (NeuroDistill) — Lanceur 1-Clic macOS & Linux
# Créé par Tarik Badri — en association avec Larbi Badri © 2026
# Référence scientifique : Mghabbar & Ratnamogan (ECAI 2020)
# ==============================================================================
set -e

cd "$(dirname "$0")/.."

echo "============================================================================"
echo "  UNIVERSITÉ NUMÉRIQUE (NeuroDistill)"
echo "  Créé par Tarik Badri — en association avec Larbi Badri"
echo "============================================================================"

if ! command -v python3 &> /dev/null; then
    echo "⚠️ Python 3 n'est pas installé. Installez-le via https://www.python.org"
    exit 1
fi

if [ ! -d ".venv" ]; then
    echo "[1/3] Création de l'environnement virtuel local..."
    python3 -m venv .venv
fi

source .venv/bin/activate

echo "[2/3] Vérification des bibliothèques (ONNX Runtime CPU/MPS, FastAPI, RAG)..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

mkdir -p libraries checkpoints reports

echo "[3/3] Démarrage du serveur local et ouverture du navigateur..."
(sleep 2 && open "http://127.0.0.1:8000" 2>/dev/null || xdg-open "http://127.0.0.1:8000" 2>/dev/null || true) &
python3 main.py
`,
  },
  {
    id: 'kd_loss_py',
    filename: 'src/training/knowledge_distillation.py',
    platformLabel: 'PyTorch — Distillation ECAI 2020',
    description:
      'Implémentation mathématique honnête de la perte de distillation multi-professeurs avec Label Smoothing actif et masque de padding strict sur KL.',
    language: 'python',
    content: `# © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
# Scientific reference: Mghabbar & Ratnamogan (ECAI 2020)

import torch
import torch.nn as nn
import torch.nn.functional as F

class MultiTeacherDistillationLoss(nn.Module):
    """
    L = (1 - alpha) * CE_smooth(y, student_logits)
        + alpha * (T ** 2) * KL(teacher_probs_T || student_probs_T)
    """
    def __init__(
        self,
        alpha: float = 0.7,
        temperature: float = 2.0,
        label_smoothing: float = 0.1,
        pad_idx: int = 0,
    ) -> None:
        super().__init__()
        if not (0.0 <= alpha <= 1.0):
            raise ValueError("alpha must be between 0.0 and 1.0")
        if temperature <= 0.0:
            raise ValueError("temperature must be strictly positive")

        self.alpha = alpha
        self.temperature = temperature
        self.pad_idx = pad_idx
        self.ce_loss = nn.CrossEntropyLoss(
            ignore_index=pad_idx,
            label_smoothing=label_smoothing,
            reduction="mean",
        )

    def forward(
        self,
        student_logits: torch.Tensor,
        teacher_logits: torch.Tensor,
        targets: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        # 1. Hard-target Cross-Entropy with real label smoothing
        vocab_size = student_logits.size(-1)
        ce = self.ce_loss(student_logits.view(-1, vocab_size), targets.view(-1))

        # 2. Soft-target KL divergence with strict padding mask
        T = self.temperature
        student_log_probs_T = F.log_softmax(student_logits / T, dim=-1)
        teacher_probs_T = F.softmax(teacher_logits.detach() / T, dim=-1)

        # Element-wise KL summed over vocabulary: shape (batch, seq_len)
        kl_per_token = F.kl_div(
            student_log_probs_T,
            teacher_probs_T,
            reduction="none",
        ).sum(dim=-1)

        non_pad_mask = (targets != self.pad_idx).float()
        valid_tokens = non_pad_mask.sum().clamp(min=1.0)
        kl = (kl_per_token * non_pad_mask).sum() / valid_tokens

        total_loss = (1.0 - self.alpha) * ce + self.alpha * (T ** 2) * kl
        return {
            "loss": total_loss,
            "ce_loss": ce.detach(),
            "kl_loss": kl.detach(),
        }
`,
  },
  {
    id: 'indra_ocr_py',
    filename: 'src/ocr/engine.py',
    platformLabel: 'Pipeline OCR & Ingestion RAG',
    description:
      'Adaptateur modulaire Indra OCR (ONNX CPU) + extraction native PDF et nettoyage contre l’injection de prompt pour nourrir les bibliothèques des professeurs.',
    language: 'python',
    content: `# © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
# OCR Engine Adapter for Indra OCR (ONNX CPU) & Native PDF Layer

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
import time
import re

@dataclass
class OCRPageResult:
    page_number: int
    markdown: str
    is_digital_layer: bool
    processing_ms: float

class OCREngine(ABC):
    @abstractmethod
    def process_file(self, file_path: Path) -> list[OCRPageResult]:
        raise NotImplementedError

class IndraOCREngine(OCREngine):
    """
    Lightweight CPU OCR engine adapter (~1M params ONNX runtime).
    Reads native PDF text layer first and applies ONNX OCR only on scanned regions.
    """
    INJECTION_PATTERNS = [
        re.compile(r"ignore\\s+(all\\s+)?(previous|prior)\\s+instructions", re.I),
        re.compile(r"oublie\\s+(toutes\\s+)?les\\s+instructions", re.I),
    ]

    def sanitize_text(self, text: str) -> str:
        clean = text
        for pattern in self.INJECTION_PATTERNS:
            clean = pattern.sub("[SEGMENT NEUTRALISÉ - SÉCURITÉ RAG]", clean)
        return clean

    def process_file(self, file_path: Path) -> list[OCRPageResult]:
        t0 = time.perf_counter()
        raw_text = file_path.read_text(encoding="utf-8", errors="replace")
        clean_text = self.sanitize_text(raw_text)
        elapsed_ms = round((time.perf_counter() - t0) * 1000, 2)
        return [
            OCRPageResult(
                page_number=1,
                markdown=clean_text,
                is_digital_layer=True,
                processing_ms=elapsed_ms,
            )
        ]
`,
  },
  {
    id: 'architecture_md',
    filename: 'docs/ARCHITECTURE.md',
    platformLabel: 'Documentation Architecture & Mermaid',
    description:
      'Architecture complète de l’Université Numérique validant l’Étape 1 et l’Étape 10.',
    language: 'markdown',
    content: `# Architecture — Université Numérique (NeuroDistill)

**Créateur du logiciel :** Tarik Badri  
**En association avec :** Larbi Badri  
**Référence scientifique :** Mghabbar & Ratnamogan (ECAI 2020), *Building a Multi-Domain Neural Machine Translation Model Using Knowledge Distillation*

\`\`\`mermaid
flowchart TB
    subgraph UI["Interface Accessible (15 à 80+ ans — Windows, macOS, Web)"]
        Home["Accueil (3 actions claires)"]
        FeedWindow["Fenêtre « Donner à lire à mes agents » (Studio OCR)"]
        AskView["Consultation & Synthèse Transdisciplinaire"]
        CaseView["Cas Pratiques & Quiz"]
    end

    subgraph API["API Locale FastAPI (CORS restreint, Zéro donnée simulée)"]
        Routes["/v1/professors · /v1/ask · /v1/ocr/upload · /v1/libraries"]
        Safety["Garde-fous Sécurité (Anti-injection OCR, Urgences 150/15/112)"]
    end

    subgraph CORE["Cœur Multi-Agents & Distillation"]
        Orch["Orchestrateur Transdisciplinaire"]
        ProfReg["Registre des 10+ Professeurs (YAML)"]
        Student["Modèle Étudiant Distillé (ONNX Int8 CPU)"]
    end

    subgraph DATA["Bibliothèques Numériques Isolées & OCR"]
        Indra["Moteur Indra OCR (CPU ONNX + Couche PDF native)"]
        RAG["Index Hybride par Professeur (Citations Page Exacte)"]
    end

    FeedWindow --> Indra --> Safety --> RAG
    Home --> AskView --> Routes --> Orch
    Orch --> ProfReg --> RAG
    ProfReg --> Student
\`\`\`
`,
  },
];
