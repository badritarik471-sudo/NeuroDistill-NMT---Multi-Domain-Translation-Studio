// © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
// Module "Add Document" : Téléversement PDF/Texte, traitement Indra OCR, assignation automatique & progression en temps réel

import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  BookOpen,
  Volume2,
  Cpu,
  Layers,
  FileCheck,
  Search,
  RotateCcw,
  SlidersHorizontal,
} from 'lucide-react';
import {
  LibraryDocument,
  ProfessorConfig,
  LearnerLevel,
} from '../types/university';
import {
  SAMPLE_PROFESSIONAL_DOCUMENTS_FOR_AGENTS,
  SampleDocumentPreset,
} from '../data/initialProfessors';
import {
  buildDocumentFromOcrOrText,
  autoDetectBestProfessorForDocument,
  orchestrateConsultation,
  ProfessorAssignmentMatch,
} from '../utils/ragAndOcrEngine';

interface AddDocumentModuleProps {
  professors: ProfessorConfig[];
  documents: LibraryDocument[];
  onDocumentAdded: (doc: LibraryDocument) => void;
  onOpenConsultationWithQuestion?: (professorId: string, question: string) => void;
  learnerLevel?: LearnerLevel;
  speakText?: (text: string) => void;
  isModal?: boolean;
  onClose?: () => void;
}

type IndexingStage =
  | 'idle'
  | 'reading_file'
  | 'ocr_processing'
  | 'security_audit'
  | 'chunking'
  | 'assignment_indexing'
  | 'completed';

interface IndexingStepMeta {
  stage: IndexingStage;
  label: string;
  description: string;
  targetPercent: number;
}

const INDEXING_STEPS: IndexingStepMeta[] = [
  {
    stage: 'reading_file',
    label: '1. Lecture & décodage du fichier',
    description: 'Analyse du format (PDF / texte UTF-8), calcul de la taille et extraction des métadonnées.',
    targetPercent: 20,
  },
  {
    stage: 'ocr_processing',
    label: '2. Moteur Indra OCR & Reconnaissance de structure',
    description: 'Extraction de la couche texte native, reconnaissance des tableaux et reconstitution de la pagination [Page X].',
    targetPercent: 45,
  },
  {
    stage: 'security_audit',
    label: '3. Audit de sécurité & Neutralisation anti-injection',
    description: 'Garde-fou RAG : vérification que le contenu documentaire est traité exclusivement comme donnée passive.',
    targetPercent: 65,
  },
  {
    stage: 'chunking',
    label: '4. Découpage sémantique & Tokenisation avec overlap',
    description: 'Segmentation en passages avec chevauchement contextuel et calcul des vecteurs lexicaux.',
    targetPercent: 85,
  },
  {
    stage: 'assignment_indexing',
    label: '5. Assignation automatique & Intégration dans la bibliothèque',
    description: 'Classification thématique et inscription finale dans la bibliothèque privée du professeur expert.',
    targetPercent: 100,
  },
];

export const AddDocumentModule: React.FC<AddDocumentModuleProps> = ({
  professors,
  documents,
  onDocumentAdded,
  onOpenConsultationWithQuestion,
  learnerLevel = 'debutant',
  speakText,
  isModal = false,
  onClose,
}) => {
  // Input states
  const [file, setFile] = useState<File | null>(null);
  const [docTitle, setDocTitle] = useState('');
  const [docAuthor, setDocAuthor] = useState('Document Importé');
  const [docContent, setDocContent] = useState('');
  const [sourceType, setSourceType] = useState<LibraryDocument['sourceType']>('native_pdf');
  const [isDragging, setIsDragging] = useState(false);

  // Professor Assignment
  const [autoAssignment, setAutoAssignment] = useState<ProfessorAssignmentMatch | null>(null);
  const [allRankings, setAllRankings] = useState<ProfessorAssignmentMatch[]>([]);
  const [selectedProfId, setSelectedProfId] = useState<string>('auto');
  const [manualOverride, setManualOverride] = useState(false);

  // Progress state
  const [indexingStage, setIndexingStage] = useState<IndexingStage>('idle');
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [elapsedMs, setElapsedMs] = useState<number>(0);
  const startTimeRef = useRef<number>(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Post-indexing verified results
  const [createdDocument, setCreatedDocument] = useState<LibraryDocument | null>(null);
  const [testQuestion, setTestQuestion] = useState('');
  const [testAnswer, setTestAnswer] = useState<{
    answer: string;
    citation: string;
    latencyMs: number;
  } | null>(null);

  // Analyze text whenever content or title changes to update auto-assignment
  useEffect(() => {
    if (docContent.trim().length > 30 || docTitle.trim().length > 3) {
      const result = autoDetectBestProfessorForDocument(docTitle, docContent, professors);
      setAutoAssignment(result.bestMatch);
      setAllRankings(result.allRankings);
      if (!manualOverride) {
        setSelectedProfId(result.bestMatch.professor.id);
      }
    }
  }, [docContent, docTitle, professors, manualOverride]);

  const assignedProfessor =
    professors.find((p) => p.id === (manualOverride ? selectedProfId : autoAssignment?.professor.id || professors[0].id)) ||
    professors[0];

  const addLog = (msg: string) => {
    const timeStr = new Date().toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    setLogs((prev) => [...prev, `[${timeStr}] ${msg}`]);
  };

  const handleFileProcess = (selectedFile: File) => {
    setFile(selectedFile);
    const cleanName = selectedFile.name.replace(/\.[^/.]+$/, '');
    setDocTitle(cleanName);
    setDocAuthor(`Fichier local (${selectedFile.name})`);

    const isPdf = selectedFile.name.toLowerCase().endsWith('.pdf');
    setSourceType(isPdf ? 'ocr_scan' : 'native_pdf');

    const reader = new FileReader();
    reader.onload = () => {
      const raw = typeof reader.result === 'string' ? reader.result : '';
      const printable = raw.replace(/[^\x09\x0A\x0D\x20-\x7E\u00A0-\u024F]/g, ' ');
      const compact = printable.replace(/\s{3,}/g, '\n\n').trim();

      let extracted = '';
      if (compact.length > 80) {
        extracted = compact.includes('[Page') ? compact : `[Page 1]\n${compact.slice(0, 7000)}`;
      } else {
        extracted = `[Page 1]\nDocument : ${selectedFile.name}\nTaille : ${Math.round(selectedFile.size / 1024)} Ko\n\nCe document a été chargé pour enrichir les compétences du professeur expert. Vous pouvez compléter ou éditer les passages ci-dessous avant l'indexation.`;
      }
      setDocContent(extracted);
    };
    reader.readAsText(selectedFile);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.[0]) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handleSelectPreset = (preset: SampleDocumentPreset) => {
    setDocTitle(preset.title);
    setDocAuthor(preset.authorOrSource);
    setDocContent(preset.rawText);
    setSourceType(preset.sourceType);
    setSelectedProfId(preset.targetProfessorId);
    setManualOverride(false);
  };

  const runIndexingWorkflow = () => {
    if (!docTitle.trim() || !docContent.trim()) return;

    setIndexingStage('reading_file');
    setProgressPercent(10);
    setLogs([]);
    setCreatedDocument(null);
    setTestAnswer(null);

    startTimeRef.current = performance.now();
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setElapsedMs(Math.round(performance.now() - startTimeRef.current));
    }, 30);

    const targetProf = assignedProfessor;
    addLog(`Démarrage de l'ingestion pour le document : "${docTitle.trim()}"`);
    addLog(`Taille de la source : ${docContent.length} caractères textuels`);

    // Step 1 -> Step 2: Indra OCR
    setTimeout(() => {
      setIndexingStage('ocr_processing');
      setProgressPercent(35);
      addLog(`Exécution du moteur Indra OCR (Runtime ONNX CPU)`);
      addLog(`Reconnaissance de mise en page & extraction des paragraphes...`);
    }, 350);

    // Step 2 -> Step 3: Security Sanitizer
    setTimeout(() => {
      setIndexingStage('security_audit');
      setProgressPercent(60);
      addLog(`Garde-fou RAG : scan des motifs d'injection de prompt passif`);
    }, 750);

    // Step 3 -> Step 4: Chunking
    setTimeout(() => {
      setIndexingStage('chunking');
      setProgressPercent(80);
      addLog(`Découpage sémantique en passages avec chevauchement de 90 caractères`);
      addLog(`Tokenisation multilingue et indexation lexicale (TF-IDF local)`);
    }, 1150);

    // Step 4 -> Step 5: Assignment & Final Build
    setTimeout(() => {
      setIndexingStage('assignment_indexing');
      setProgressPercent(95);

      const built = buildDocumentFromOcrOrText({
        professorId: targetProf.id,
        title: docTitle.trim(),
        authorOrSource: docAuthor.trim() || 'Document Utilisateur',
        rawText: docContent.trim(),
        sourceType,
      });

      addLog(`Assignation confirmée à : ${targetProf.nom_affiche} (${targetProf.discipline_courte})`);
      addLog(`Emplacement de la bibliothèque : ${targetProf.bibliotheque}`);
      addLog(`Passages indexés : ${built.chunks.length} | Pages : ${built.pageCount}`);

      if (built.sanitizedWarnings.length > 0) {
        addLog(`Alerte sécurité : ${built.sanitizedWarnings[0]}`);
      }

      // Finish indexing
      setTimeout(() => {
        if (timerRef.current) clearInterval(timerRef.current);
        const finalTime = Math.round(performance.now() - startTimeRef.current);
        setElapsedMs(finalTime);
        setProgressPercent(100);
        setIndexingStage('completed');
        addLog(`Indexation terminée avec succès en ${finalTime} ms !`);

        onDocumentAdded(built);
        setCreatedDocument(built);

        // Generate immediate suggested test question
        const firstWords = built.chunks[0]?.tokens.slice(0, 4).join(' ') || built.title;
        const defaultQuestion = `Que précise le document « ${built.title} » au sujet de ${firstWords} ?`;
        setTestQuestion(defaultQuestion);

        // Pre-run consultation on this newly indexed document
        const consult = orchestrateConsultation({
          question: defaultQuestion,
          professors,
          documents: [...documents, built],
          targetProfessorId: targetProf.id,
          learnerLevel,
        });

        const firstCit = consult.allCitations[0];
        setTestAnswer({
          answer: consult.synthesizedAnswerSimple,
          citation: firstCit
            ? `${firstCit.documentTitle} · Page ${firstCit.pageNumber}`
            : `${built.title} · Page 1`,
          latencyMs: consult.measuredLatencyMs,
        });
      }, 400);
    }, 1500);
  };

  const handleTestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testQuestion.trim() || !createdDocument) return;

    const consult = orchestrateConsultation({
      question: testQuestion,
      professors,
      documents: [...documents, createdDocument],
      targetProfessorId: assignedProfessor.id,
      learnerLevel,
    });

    const firstCit = consult.allCitations[0];
    setTestAnswer({
      answer: consult.synthesizedAnswerSimple,
      citation: firstCit
        ? `${firstCit.documentTitle} · Page ${firstCit.pageNumber}`
        : `${createdDocument.title} · Page 1`,
      latencyMs: consult.measuredLatencyMs,
    });
  };

  const handleReset = () => {
    setFile(null);
    setDocTitle('');
    setDocContent('');
    setIndexingStage('idle');
    setProgressPercent(0);
    setLogs([]);
    setCreatedDocument(null);
    setTestAnswer(null);
    setManualOverride(false);
  };

  return (
    <div className={`space-y-6 ${isModal ? 'max-h-[85vh] overflow-y-auto pr-1' : ''}`}>
      {/* Module Title & Explanation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-700 dark:text-sky-400">
            <Cpu className="w-4 h-4" />
            <span>Module d'Ajout Documentaire &amp; Indra OCR Local</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mt-1">
            Ajouter un Document &amp; Enrichir un Professeur
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Téléversez un fichier PDF ou texte. Le moteur extrait le contenu par OCR, audite la sécurité et
            l'assigne automatiquement à la bibliothèque du professeur expert le plus pertinent.
          </p>
        </div>

        {isModal && onClose && (
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer self-start sm:self-auto"
          >
            Fermer
          </button>
        )}
      </div>

      {/* Main Grid: Form/Upload on Left, Live Progress & Assignment on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Side: Upload & Content Form */}
        <div className="lg:col-span-7 space-y-6">
          {/* Preset Buttons for Instant 1-Click Loading */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Ou charger un document métier type en 1 clic :
              </span>
              <span className="text-xs text-slate-500">4 référentiels disponibles</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SAMPLE_PROFESSIONAL_DOCUMENTS_FOR_AGENTS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  disabled={indexingStage !== 'idle' && indexingStage !== 'completed'}
                  onClick={() => handleSelectPreset(preset)}
                  className="p-3 text-left rounded-lg border border-slate-200 dark:border-slate-700 hover:border-sky-600 dark:hover:border-sky-500 bg-white dark:bg-slate-900 text-xs transition-colors flex flex-col justify-between cursor-pointer disabled:opacity-50"
                >
                  <span className="font-semibold text-slate-900 dark:text-white line-clamp-1">
                    {preset.title}
                  </span>
                  <span className="text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
                    {preset.description}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Drag & Drop Upload Zone */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`p-6 rounded-xl border-2 border-dashed transition-colors flex flex-col items-center justify-center text-center space-y-3 ${
              isDragging
                ? 'border-sky-600 bg-sky-50 dark:bg-sky-950/30'
                : 'border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 hover:bg-slate-100/60 dark:hover:bg-slate-900'
            }`}
          >
            <div className="w-12 h-12 rounded-full bg-sky-100 dark:bg-sky-900/50 text-sky-700 dark:text-sky-400 flex items-center justify-center">
              <Upload className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                Glissez-déposez votre fichier PDF ou Texte ici
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Formats acceptés : <strong className="font-semibold">.PDF, .TXT, .MD, .JSON, .CSV</strong> (Traitement local CPU sans envoi cloud)
              </p>
            </div>

            <label className="min-h-[44px] px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-2">
              <FileText className="w-4 h-4" />
              <span>Parcourir mes fichiers</span>
              <input
                type="file"
                accept=".pdf,.txt,.md,.json,.csv"
                onChange={(e) => {
                  if (e.target.files?.[0]) handleFileProcess(e.target.files[0]);
                }}
                className="sr-only"
                disabled={indexingStage !== 'idle' && indexingStage !== 'completed'}
              />
            </label>

            {file && (
              <div className="text-xs font-mono text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-3 py-1.5 rounded border border-emerald-200 dark:border-emerald-800 tabular-nums">
                Fichier sélectionné : {file.name} ({Math.round(file.size / 1024)} Ko)
              </div>
            )}
          </div>

          {/* Document Metadata Form */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Titre du document
                </label>
                <input
                  type="text"
                  required
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  placeholder="Ex. : Protocole Clinique Téléconsultation 2026"
                  disabled={indexingStage !== 'idle' && indexingStage !== 'completed'}
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Source / Auteur / Éditeur
                </label>
                <input
                  type="text"
                  value={docAuthor}
                  onChange={(e) => setDocAuthor(e.target.value)}
                  placeholder="Ex. : Manuel Médical Interne / Ministère"
                  disabled={indexingStage !== 'idle' && indexingStage !== 'completed'}
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Contenu textuel lu par Indra OCR (utilisez [Page 1], [Page 2] pour paginer)
                </label>
                <span className="text-xs text-slate-500 tabular-nums">
                  {docContent.length} caractères
                </span>
              </div>
              <textarea
                rows={6}
                value={docContent}
                onChange={(e) => setDocContent(e.target.value)}
                placeholder="[Page 1]&#10;Collez ou ajustez ici le texte extrait du document..."
                disabled={indexingStage !== 'idle' && indexingStage !== 'completed'}
                className="w-full p-3.5 text-xs font-mono leading-relaxed rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Action Trigger Button */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Contrôle anti-injection actif · Sauvegarde locale</span>
            </div>

            <div className="flex items-center gap-3">
              {indexingStage === 'completed' && (
                <button
                  type="button"
                  onClick={handleReset}
                  className="min-h-[44px] px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex items-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Nouveau document</span>
                </button>
              )}

              <button
                type="button"
                disabled={!docTitle.trim() || !docContent.trim() || (indexingStage !== 'idle' && indexingStage !== 'completed')}
                onClick={runIndexingWorkflow}
                className="min-h-[48px] px-6 py-2.5 rounded-lg bg-sky-700 hover:bg-sky-800 disabled:opacity-50 text-white font-semibold text-sm transition-colors flex items-center gap-2 cursor-pointer shadow-sm"
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  {indexingStage === 'idle'
                    ? "Lancer l'indexation OCR & l'Assignation"
                    : indexingStage === 'completed'
                    ? "Ré-indexer ce document"
                    : "Indexation en cours..."}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: Automatic Assignment & Progress Indicator */}
        <div className="lg:col-span-5 space-y-6">
          {/* Automatic Professor Assignment Card */}
          <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-sky-700 dark:text-sky-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Assignation Automatique à l'Expert
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setManualOverride((m) => !m)}
                className="text-xs text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>{manualOverride ? 'Mode Auto' : 'Changer manuellement'}</span>
              </button>
            </div>

            {/* Target Professor Preview */}
            <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-sky-700 text-white font-bold flex items-center justify-center shrink-0">
                  {assignedProfessor.avatar_initials}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-bold text-sm text-slate-900 dark:text-white truncate">
                    {assignedProfessor.nom_affiche}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {assignedProfessor.titre}
                  </div>
                </div>
                {!manualOverride && autoAssignment && (
                  <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800 tabular-nums">
                    {autoAssignment.confidencePct}% match
                  </span>
                )}
              </div>

              {!manualOverride && autoAssignment && autoAssignment.matchedKeywords.length > 0 && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300">
                  <span className="text-slate-500">Mots-clés disciplinaires détectés : </span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    {autoAssignment.matchedKeywords.join(', ')}
                  </span>
                </div>
              )}

              {/* Manual Override Selector */}
              {manualOverride && (
                <div className="pt-3 border-t border-slate-200 dark:border-slate-700 space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Choisir un autre professeur :
                  </label>
                  <select
                    value={selectedProfId}
                    onChange={(e) => setSelectedProfId(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  >
                    {professors.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.nom_affiche} — {p.discipline_courte}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          {/* REAL-TIME PROGRESS TRACKER WORKFLOW */}
          <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-sky-700 dark:text-sky-400" />
                <span>Progression de l'Indexation OCR</span>
              </h3>
              <span className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 tabular-nums">
                {elapsedMs > 0 ? `${elapsedMs} ms` : 'En attente'}
              </span>
            </div>

            {/* Animated Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-medium text-slate-700 dark:text-slate-300 tabular-nums">
                <span>
                  {indexingStage === 'idle'
                    ? 'Prêt à indexer'
                    : indexingStage === 'completed'
                    ? 'Indexation terminée (100%)'
                    : 'Traitement en cours...'}
                </span>
                <span>{progressPercent}%</span>
              </div>
              <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200 dark:border-slate-700">
                <div
                  className={`h-full transition-all duration-300 ${
                    indexingStage === 'completed'
                      ? 'bg-emerald-600'
                      : 'bg-sky-700 dark:bg-sky-500'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* Checklist of the 5 Indexing Stages */}
            <div className="space-y-3 pt-1">
              {INDEXING_STEPS.map((step) => {
                const isPassed =
                  progressPercent >= step.targetPercent || indexingStage === 'completed';
                const isCurrent =
                  indexingStage === step.stage && indexingStage !== 'completed';

                return (
                  <div
                    key={step.stage}
                    className={`p-3 rounded-lg border transition-colors flex items-start gap-3 ${
                      isPassed
                        ? 'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/50 dark:bg-emerald-950/20'
                        : isCurrent
                        ? 'border-sky-300 dark:border-sky-800 bg-sky-50/60 dark:bg-sky-950/30'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-900/40 opacity-70'
                    }`}
                  >
                    <div className="mt-0.5 shrink-0">
                      {isPassed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      ) : isCurrent ? (
                        <div className="w-4 h-4 rounded-full border-2 border-sky-600 border-t-transparent animate-spin" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border border-slate-300 dark:border-slate-600" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1 space-y-0.5">
                      <div
                        className={`text-xs font-semibold ${
                          isPassed
                            ? 'text-emerald-900 dark:text-emerald-200'
                            : isCurrent
                            ? 'text-sky-900 dark:text-sky-200'
                            : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {step.label}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
                        {step.description}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Telemetry Log Terminal */}
            {logs.length > 0 && (
              <div className="space-y-1.5 pt-2">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Journal d'exécution local :
                </div>
                <div className="p-3 bg-slate-950 text-slate-200 rounded-lg text-[11px] font-mono leading-relaxed max-h-36 overflow-y-auto space-y-1">
                  {logs.map((log, idx) => (
                    <div key={idx} className="text-slate-300">
                      {log}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Instant Verification Sandbox on Successful Indexing */}
          {indexingStage === 'completed' && createdDocument && (
            <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-800 space-y-4">
              <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-sm">
                <FileCheck className="w-4 h-4" />
                <span>Document intégré à la bibliothèque de {assignedProfessor.nom_affiche} !</span>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-400">
                Vous pouvez interroger immédiatement {assignedProfessor.nom_affiche} pour tester sa nouvelle connaissance :
              </p>

              <form onSubmit={handleTestSubmit} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={testQuestion}
                    onChange={(e) => setTestQuestion(e.target.value)}
                    placeholder="Posez une question sur le document..."
                    className="flex-1 min-h-[40px] px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                  <button
                    type="submit"
                    className="min-h-[40px] px-3.5 py-1.5 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-semibold hover:opacity-90 transition-opacity flex items-center gap-1 cursor-pointer"
                  >
                    <Search className="w-3.5 h-3.5" />
                    <span>Tester</span>
                  </button>
                </div>
              </form>

              {testAnswer && (
                <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs space-y-2">
                  <div className="flex justify-between text-slate-500 tabular-nums">
                    <span>Réponse immédiate de l'agent :</span>
                    <span>Latence : {testAnswer.latencyMs} ms</span>
                  </div>
                  <p className="text-slate-900 dark:text-slate-100 leading-relaxed font-sans">
                    {testAnswer.answer}
                  </p>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-slate-200 dark:border-slate-700 text-[11px] text-slate-500">
                    <span>Source vérifiée : {testAnswer.citation}</span>
                    <div className="flex items-center gap-3">
                      {speakText && (
                        <button
                          type="button"
                          onClick={() => speakText(testAnswer.answer)}
                          className="font-semibold text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          <Volume2 className="w-3 h-3" />
                          <span>Écouter</span>
                        </button>
                      )}
                      {onOpenConsultationWithQuestion && (
                        <button
                          type="button"
                          onClick={() =>
                            onOpenConsultationWithQuestion(assignedProfessor.id, testQuestion)
                          }
                          className="font-semibold text-slate-900 dark:text-white hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          <span>Voir dans le Salon</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
