// © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
// Fenêtre « Donner à lire à mes agents » (Studio OCR & Enrichissement Professionnel RAG)

import React, { useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  FileText,
  Trash2,
  Volume2,
  ArrowRight,
  Search,
  Sparkles,
  Layers,
  FolderOpen,
} from 'lucide-react';
import {
  LearnerLevel,
  LibraryDocument,
  ProfessorConfig,
} from '../types/university';
import { orchestrateConsultation } from '../utils/ragAndOcrEngine';
import { AddDocumentModule } from './AddDocumentModule';

interface AgentDocumentTrainerWindowProps {
  professors: ProfessorConfig[];
  documents: LibraryDocument[];
  selectedProfessorId: string;
  onSelectProfessor: (id: string) => void;
  onAddDocument: (doc: LibraryDocument) => void;
  onDeleteDocument: (docId: string) => void;
  onJumpToConsultationWithQuestion: (professorId: string, question: string) => void;
  learnerLevel: LearnerLevel;
  speakText: (text: string) => void;
  ocrHeroImage: string;
}

export const AgentDocumentTrainerWindow: React.FC<AgentDocumentTrainerWindowProps> = ({
  professors,
  documents,
  selectedProfessorId,
  onSelectProfessor,
  onAddDocument,
  onDeleteDocument,
  onJumpToConsultationWithQuestion,
  learnerLevel,
  speakText,
  ocrHeroImage,
}) => {
  const activeProf =
    professors.find((p) => p.id === selectedProfessorId) || professors[0];

  const [activeSubTab, setActiveSubTab] = useState<'upload' | 'browse'>('upload');
  const [quickTestQuestion, setQuickTestQuestion] = useState('');
  const [quickTestAnswer, setQuickTestAnswer] = useState<{
    answer: string;
    citation: string;
    latencyMs: number;
  } | null>(null);
  const [imageError, setImageError] = useState(false);

  const profDocuments = documents.filter((d) => d.professorId === activeProf.id);
  const totalChunksForProf = profDocuments.reduce(
    (sum, d) => sum + d.chunks.length,
    0
  );
  const totalPagesForProf = profDocuments.reduce(
    (sum, d) => sum + d.pageCount,
    0
  );

  const handleRunQuickVerification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTestQuestion.trim()) return;

    const consult = orchestrateConsultation({
      question: quickTestQuestion,
      professors,
      documents,
      targetProfessorId: activeProf.id,
      learnerLevel,
    });
    const firstCit = consult.allCitations[0];
    setQuickTestAnswer({
      answer: consult.synthesizedAnswerSimple,
      citation: firstCit
        ? `${firstCit.documentTitle} · Page ${firstCit.pageNumber}`
        : 'Aucune source correspondante',
      latencyMs: consult.measuredLatencyMs,
    });
  };

  return (
    <section aria-labelledby="trainer-window-heading" className="space-y-8">
      {/* Header Banner of the Document Reading Window */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8">
        <div className="lg:col-span-7 flex flex-col justify-between space-y-5">
          <div className="space-y-3">
            <p className="text-sm font-medium text-sky-700 dark:text-sky-400">
              Studio de Lecture Indra OCR · Windows, macOS &amp; Web Local
            </p>
            <h1
              id="trainer-window-heading"
              className="text-2xl lg:text-3xl font-bold text-slate-900 dark:text-white tracking-tight"
            >
              Fenêtre de Lecture : Donnez vos documents à lire à vos Agents pour les rendre plus professionnels
            </h1>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              Téléversez vos PDF, contrats, livres ou cours. Le moteur Indra OCR extrait les pages,
              filtre les menaces d'injection et assigne automatiquement l'ouvrage au bon professeur expert
              avec un suivi d'indexation étape par étape.
            </p>
          </div>

          <div className="pt-2 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-600 dark:text-slate-400 tabular-nums border-t border-slate-100 dark:border-slate-800">
            <span>Traitement 100 % local (CPU / ONNX)</span>
            <span aria-hidden="true">·</span>
            <span>Assignation automatique par domaine</span>
            <span aria-hidden="true">·</span>
            <span>Progression détaillée en 5 étapes</span>
          </div>
        </div>

        <div className="lg:col-span-5 relative rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800 min-h-[200px]">
          {!imageError ? (
            <img
              src={ocrHeroImage}
              alt="Lecture et numérisation structurée d'un ouvrage technique et de notes manuscrites pour l'agent IA"
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-slate-100 dark:bg-slate-800">
              <BookOpen className="w-10 h-10 text-sky-700 mb-2" />
              <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                Studio d’Indexation Documentaire &amp; Indra OCR
              </span>
            </div>
          )}
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/45 to-transparent p-4 text-white">
            <p className="text-xs font-medium">
              Pipeline Indra OCR · Couche PDF native + analyse de mise en page et tableaux
            </p>
          </div>
        </div>
      </div>

      {/* Sub-Tabs: Add Document Module vs Library Explorer */}
      <div className="flex items-center gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <button
          type="button"
          onClick={() => setActiveSubTab('upload')}
          className={`min-h-[44px] px-4 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'upload'
              ? 'bg-sky-700 text-white'
              : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Module Ajouter un Document (OCR &amp; Suivi en Direct)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('browse')}
          className={`min-h-[44px] px-4 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'browse'
              ? 'bg-sky-700 text-white'
              : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
          }`}
        >
          <FolderOpen className="w-4 h-4" />
          <span>Consulter les Bibliothèques des Professeurs ({documents.length} docs)</span>
        </button>
      </div>

      {/* VIEW 1: ADD DOCUMENT MODULE */}
      {activeSubTab === 'upload' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8">
          <AddDocumentModule
            professors={professors}
            documents={documents}
            onDocumentAdded={onAddDocument}
            onOpenConsultationWithQuestion={onJumpToConsultationWithQuestion}
            learnerLevel={learnerLevel}
            speakText={speakText}
          />
        </div>
      )}

      {/* VIEW 2: BROWSE PROFESSOR LIBRARIES */}
      {activeSubTab === 'browse' && (
        <div className="space-y-6">
          {/* Step 1: Select which Digital Professor Agent to inspect */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                  Sélectionnez un Professeur pour explorer sa bibliothèque
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Chaque professeur possède son espace isolé ({activeProf.bibliotheque}).
                </p>
              </div>
              <div className="text-sm text-slate-600 dark:text-slate-300 tabular-nums">
                <span>{profDocuments.length} ouvrages</span>
                <span className="mx-2" aria-hidden="true">·</span>
                <span>{totalPagesForProf} pages</span>
                <span className="mx-2" aria-hidden="true">·</span>
                <span>{totalChunksForProf} passages indexés</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {professors.map((prof) => {
                const isSelected = prof.id === activeProf.id;
                const docCount = documents.filter((d) => d.professorId === prof.id).length;
                return (
                  <button
                    key={prof.id}
                    type="button"
                    onClick={() => {
                      onSelectProfessor(prof.id);
                      setQuickTestAnswer(null);
                    }}
                    className={`min-h-[56px] p-3.5 rounded-lg border text-left transition-colors flex flex-col justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-sky-700 text-white border-sky-700 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700 hover:border-sky-600'
                    }`}
                  >
                    <div className="font-semibold text-base truncate">{prof.nom_affiche}</div>
                    <div
                      className={`text-xs truncate tabular-nums mt-1 ${
                        isSelected ? 'text-sky-100' : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {prof.discipline_courte} · {docCount} doc{docCount > 1 ? 's' : ''}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Library Content List & Test */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left: Document List */}
            <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  Ouvrages enregistrés pour {activeProf.nom_affiche}
                </h3>
                <span className="text-xs text-slate-500 tabular-nums">
                  {profDocuments.length} document(s)
                </span>
              </div>

              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                {profDocuments.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                          <FileText className="w-4 h-4 text-sky-700 dark:text-sky-400 shrink-0" />
                          <span>{doc.title}</span>
                        </h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                          {doc.authorOrSource} · {doc.pageCount} page(s) · {doc.chunks.length} passages indexés · OCR en {doc.ocrProcessingMs} ms
                        </p>
                      </div>
                      {profDocuments.length > 1 && (
                        <button
                          type="button"
                          onClick={() => onDeleteDocument(doc.id)}
                          title="Retirer ce document de la bibliothèque"
                          className="p-2 text-slate-400 hover:text-red-600 transition-colors rounded-md cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                      Extrait Page 1 : « {doc.chunks[0]?.content} »
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Instant Tester */}
            <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-4">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Interroger {activeProf.nom_affiche} sur sa bibliothèque
              </h3>

              <form onSubmit={handleRunQuickVerification} className="space-y-3">
                <input
                  type="text"
                  value={quickTestQuestion}
                  onChange={(e) => setQuickTestQuestion(e.target.value)}
                  placeholder={`Posez une question à ${activeProf.nom_affiche}...`}
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
                />
                <button
                  type="submit"
                  className="w-full min-h-[44px] px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Search className="w-4 h-4" />
                  <span>Poser la question</span>
                </button>
              </form>

              {quickTestAnswer && (
                <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-500 tabular-nums">
                    <span>Réponse :</span>
                    <span>{quickTestAnswer.latencyMs} ms</span>
                  </div>
                  <p className="text-sm text-slate-900 dark:text-slate-100 leading-relaxed">
                    {quickTestAnswer.answer}
                  </p>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-500">
                    <span>Source : {quickTestAnswer.citation}</span>
                    <button
                      type="button"
                      onClick={() => speakText(quickTestAnswer.answer)}
                      className="font-semibold text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Écouter</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
