// © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
// Référence scientifique : Mghabbar & Ratnamogan (ECAI 2020)

import React, { useState } from 'react';
import {
  CheckCircle2,
  Copy,
  Download,
  Play,
  RotateCcw,
  Terminal,
  Cpu,
} from 'lucide-react';
import {
  DELIVERABLE_PROJECT_FILES,
  DeliverableCodeFile,
  STEP1_AUDIT_TABLE,
} from '../data/pythonProjectFiles';
import { runRealDistillationSimulation } from '../utils/ragAndOcrEngine';
import { DistillationRunResult } from '../types/university';

interface DistillationAndExportStudioProps {
  distillDiagramImage: string;
}

export const DistillationAndExportStudio: React.FC<
  DistillationAndExportStudioProps
> = ({ distillDiagramImage }) => {
  const [alpha, setAlpha] = useState(0.7);
  const [temperature, setTemperature] = useState(2.0);
  const [labelSmoothing, setLabelSmoothing] = useState(0.1);
  const [simResult, setSimResult] = useState<DistillationRunResult>(() =>
    runRealDistillationSimulation({
      alpha: 0.7,
      temperature: 2.0,
      labelSmoothing: 0.1,
      steps: 12,
    })
  );

  const [selectedFileId, setSelectedFileId] = useState<string>(
    DELIVERABLE_PROJECT_FILES[0].id
  );
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [imgError, setImgError] = useState(false);

  const activeFile: DeliverableCodeFile =
    DELIVERABLE_PROJECT_FILES.find((f) => f.id === selectedFileId) ||
    DELIVERABLE_PROJECT_FILES[0];

  const handleRunSimulation = () => {
    const res = runRealDistillationSimulation({
      alpha,
      temperature,
      labelSmoothing,
      steps: 12,
    });
    setSimResult(res);
  };

  const handleResetParams = () => {
    setAlpha(0.7);
    setTemperature(2.0);
    setLabelSmoothing(0.1);
    setSimResult(
      runRealDistillationSimulation({
        alpha: 0.7,
        temperature: 2.0,
        labelSmoothing: 0.1,
        steps: 12,
      })
    );
  };

  const handleDownloadFile = (file: DeliverableCodeFile) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const baseName = file.filename.split('/').pop() || 'script.txt';
    a.download = baseName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyFile = (file: DeliverableCodeFile) => {
    navigator.clipboard.writeText(file.content);
    setCopiedId(file.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <section className="space-y-10" aria-labelledby="distill-export-heading">
      {/* Section 1: Windows & macOS 1-Click Packaging + Architecture */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b border-slate-100 dark:border-slate-800 pb-6">
          <div className="space-y-2 max-w-2xl">
            <p className="text-sm font-medium text-sky-700 dark:text-sky-400">
              Installation 1-Clic · Windows (.bat) &amp; macOS (.sh) · Mode Hors-Ligne CPU
            </p>
            <h1
              id="distill-export-heading"
              className="text-2xl lg:text-3xl font-bold text-slate-900 dark:text-white tracking-tight"
            >
              Pack Desktop Windows &amp; macOS + Laboratoire de Distillation Multi-Professeurs
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Téléchargez directement les lanceurs automatiques pour Windows et macOS ainsi que
              le code Python/PyTorch assaini (Étape 1 à 12). Créé par{' '}
              <strong className="font-semibold text-slate-900 dark:text-white">
                Tarik Badri
              </strong>{' '}
              en association avec{' '}
              <strong className="font-semibold text-slate-900 dark:text-white">
                Larbi Badri
              </strong>
              .
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => handleDownloadFile(DELIVERABLE_PROJECT_FILES[0])}
              className="min-h-[48px] px-4 py-2.5 rounded-lg bg-sky-700 hover:bg-sky-800 text-white text-sm font-semibold transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Télécharger pour Windows (.bat)</span>
            </button>
            <button
              type="button"
              onClick={() => handleDownloadFile(DELIVERABLE_PROJECT_FILES[1])}
              className="min-h-[48px] px-4 py-2.5 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-sm font-semibold hover:opacity-90 transition-opacity flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Télécharger pour macOS (.sh)</span>
            </button>
          </div>
        </div>

        {/* File Inspector */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-4 space-y-2">
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
              Fichiers livrables prêts pour votre dépôt local :
            </p>
            {DELIVERABLE_PROJECT_FILES.map((file) => {
              const active = file.id === activeFile.id;
              return (
                <button
                  key={file.id}
                  type="button"
                  onClick={() => setSelectedFileId(file.id)}
                  className={`w-full p-3.5 rounded-lg border text-left transition-colors ${
                    active
                      ? 'bg-sky-700 text-white border-sky-700'
                      : 'bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700 hover:border-sky-600'
                  }`}
                >
                  <div className="text-sm font-mono font-medium truncate">
                    {file.filename}
                  </div>
                  <div
                    className={`text-xs mt-1 truncate ${
                      active ? 'text-sky-100' : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {file.platformLabel}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="lg:col-span-8 bg-slate-950 text-slate-100 rounded-xl border border-slate-800 overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm font-mono text-sky-400">
                <Terminal className="w-4 h-4 shrink-0" />
                <span>{activeFile.filename}</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => handleCopyFile(activeFile)}
                  className="px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedId === activeFile.id ? 'Copié !' : 'Copier le code'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDownloadFile(activeFile)}
                  className="px-3 py-1.5 rounded-md bg-sky-700 hover:bg-sky-600 text-xs font-medium text-white flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Télécharger</span>
                </button>
              </div>
            </div>
            <div className="px-5 py-3 bg-slate-900/50 border-b border-slate-800 text-xs text-slate-300">
              {activeFile.description}
            </div>
            <pre className="p-5 text-xs font-mono leading-relaxed overflow-x-auto max-h-[380px]">
              <code>{activeFile.content}</code>
            </pre>
          </div>
        </div>
      </div>

      {/* Section 2: Interactive Knowledge Distillation Simulator (Two-Zone Sandbox Layout) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-6">
        <div className="space-y-2">
          <h2 className="text-xl lg:text-2xl font-bold text-slate-900 dark:text-white">
            Pour les curieux : Simulateur Mathématique Réel de Distillation (ECAI 2020)
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300">
            Vérification en direct de l’Étape 2 et de l’Étape 6 : calcul réel sur mini-batch
            jouet (étiqueté « démonstration ») de la fonction de perte{' '}
            <code className="font-mono text-xs bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
              L = (1 - α)·CE_smooth + α·T²·KL
            </code>{' '}
            avec application effective du <code className="font-mono text-xs">label_smoothing</code>{' '}
            et masque strict des tokens de padding.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Zone (7 cols): Interactive Stage & Convergence Curve */}
          <div className="lg:col-span-7 space-y-5">
            <div className="relative rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950 h-52">
              {!imgError ? (
                <img
                  src={distillDiagramImage}
                  alt="Schéma de convergence des modèles Professeurs spécialisés vers le modèle Étudiant polyvalent"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover opacity-85"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-slate-400 text-sm">
                  <Cpu className="w-6 h-6 mr-2" />
                  <span>Convergence Multi-Professeurs → Modèle Étudiant</span>
                </div>
              )}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/50 to-transparent p-4 text-white flex items-center justify-between text-xs tabular-nums">
                <span>Référence scientifique : Mghabbar &amp; Ratnamogan (ECAI 2020)</span>
                <span>Temps CPU mesuré : {simResult.measuredExecutionMs} ms</span>
              </div>
            </div>

            {/* Measured Loss Convergence Table / Bars */}
            <div className="p-5 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                <span className="font-semibold text-slate-900 dark:text-white">
                  Décroissance mesurée de la perte sur 12 itérations (Mini-batch démonstration)
                </span>
                <span className="text-xs text-emerald-700 dark:text-emerald-400 font-medium flex items-center gap-1 tabular-nums">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    Loss initiale {simResult.initialLoss} → finale {simResult.finalLoss}
                  </span>
                </span>
              </div>

              <div className="space-y-2">
                {simResult.lossHistory.map((row) => {
                  const widthPct = Math.min(
                    100,
                    Math.max(8, Math.round((row.totalLoss / Math.max(simResult.initialLoss, 0.1)) * 100))
                  );
                  return (
                    <div
                      key={row.step}
                      className="grid grid-cols-12 items-center gap-3 text-xs font-mono tabular-nums"
                    >
                      <span className="col-span-2 text-slate-600 dark:text-slate-400">
                        Étape {row.step}
                      </span>
                      <div className="col-span-6 h-3 bg-slate-200 dark:bg-slate-700 rounded overflow-hidden">
                        <div
                          className="h-full bg-sky-700 dark:bg-sky-500 transition-transform"
                          style={{ width: `${widthPct}%` }}
                        />
                      </div>
                      <span className="col-span-4 text-right text-slate-800 dark:text-slate-200">
                        L={row.totalLoss.toFixed(3)} (CE:{row.ceLoss.toFixed(2)} · KL:{row.klLoss.toFixed(2)})
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Zone (5 cols): Parameter Sliders & Controls */}
          <div className="lg:col-span-5 p-6 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-5">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Paramètres de Distillation
            </h3>

            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm font-medium text-slate-800 dark:text-slate-200 mb-1 tabular-nums">
                  <label htmlFor="slider-alpha">Poids des Professeurs (α)</label>
                  <span>{alpha.toFixed(2)}</span>
                </div>
                <input
                  id="slider-alpha"
                  type="range"
                  min={0.1}
                  max={0.95}
                  step={0.05}
                  value={alpha}
                  onChange={(e) => setAlpha(parseFloat(e.target.value))}
                  className="w-full accent-sky-700"
                />
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Équilibre entre la vérité terrain (1-α) et les probabilités des professeurs (α).
                </p>
              </div>

              <div>
                <div className="flex justify-between text-sm font-medium text-slate-800 dark:text-slate-200 mb-1 tabular-nums">
                  <label htmlFor="slider-temp">Température d’adoucissement (T)</label>
                  <span>{temperature.toFixed(1)}</span>
                </div>
                <input
                  id="slider-temp"
                  type="range"
                  min={1.0}
                  max={5.0}
                  step={0.5}
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-full accent-sky-700"
                />
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Plus T est élevé, plus le modèle Étudiant capte les nuances secondaires des professeurs.
                </p>
              </div>

              <div>
                <div className="flex justify-between text-sm font-medium text-slate-800 dark:text-slate-200 mb-1 tabular-nums">
                  <label htmlFor="slider-smooth">Lissage des étiquettes (Label Smoothing ε)</label>
                  <span>{labelSmoothing.toFixed(2)}</span>
                </div>
                <input
                  id="slider-smooth"
                  type="range"
                  min={0.0}
                  max={0.3}
                  step={0.05}
                  value={labelSmoothing}
                  onChange={(e) => setLabelSmoothing(parseFloat(e.target.value))}
                  className="w-full accent-sky-700"
                />
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Évite la sur-confiance du modèle et régularise l’entropie croisée.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleRunSimulation}
                className="flex-1 min-h-[48px] px-4 py-2.5 rounded-lg bg-sky-700 hover:bg-sky-800 text-white font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-4 h-4" />
                <span>Calculer sur mini-batch</span>
              </button>
              <button
                type="button"
                onClick={handleResetParams}
                className="min-h-[48px] px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Réinitialiser</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Section 3: Step 1 Technical Audit Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-4">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Rapport d’Audit Technique (Étape 1 &amp; Étape 2 validées)
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Bilan transparent de l’assainissement du projet initial multi_domain_nmt_saas.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                <th className="py-3 pr-4 font-semibold">Fichier / Module</th>
                <th className="py-3 px-4 font-semibold">Constat initial</th>
                <th className="py-3 px-4 font-semibold">Diagnostic</th>
                <th className="py-3 pl-4 font-semibold">Correction appliquée</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {STEP1_AUDIT_TABLE.map((row) => (
                <tr key={row.modulePath} className="align-top">
                  <td className="py-3.5 pr-4 font-mono text-xs text-slate-900 dark:text-slate-100 whitespace-nowrap">
                    {row.modulePath}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                    {row.currentState}
                  </td>
                  <td className="py-3.5 px-4 font-medium text-slate-800 dark:text-slate-200 whitespace-nowrap">
                    {row.realOrMock}
                  </td>
                  <td className="py-3.5 pl-4 text-slate-600 dark:text-slate-300">
                    {row.requiredAction}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
