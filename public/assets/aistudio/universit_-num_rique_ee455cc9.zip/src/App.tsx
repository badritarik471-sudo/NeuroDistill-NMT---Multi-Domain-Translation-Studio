// © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
// Référence scientifique : Mghabbar & Ratnamogan (ECAI 2020)

import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  CheckCircle2,
  Download,
  FilePlus2,
  GraduationCap,
  MessageSquare,
  Mic,
  Moon,
  Plus,
  Send,
  ShieldAlert,
  Sun,
  Trash2,
  Volume2,
  VolumeX,
  ArrowRight,
  Upload,
} from 'lucide-react';
import {
  ConsultationResponse,
  LearnerLevel,
  LearnerProgress,
  LibraryDocument,
  ProfessorConfig,
  SupportedLanguage,
  UserProfilePreset,
} from './types/university';
import {
  buildInitialLibraries,
  INITIAL_PROFESSORS,
  INITIAL_QUIZ_QUESTIONS,
  PREBUILT_CASE_STUDIES,
} from './data/initialProfessors';
import { orchestrateConsultation } from './utils/ragAndOcrEngine';
import { AgentDocumentTrainerWindow } from './components/AgentDocumentTrainerWindow';
import { DistillationAndExportStudio } from './components/DistillationAndExportStudio';
import { AddDocumentModule } from './components/AddDocumentModule';

const HERO_UNIVERSITY_IMAGE =
  '/src/assets/images/hero_digital_university_1792785727653.jpg';
const DISTILL_DIAGRAM_IMAGE =
  '/src/assets/images/diagram_knowledge_distillation_1792785728795.jpg';
const OCR_STUDIO_IMAGE =
  '/src/assets/images/ocr_document_ingestion_1792785729180.jpg';

type ActiveTab = 'accueil' | 'consultation' | 'trainer_ocr' | 'apprentissage' | 'distillation';

export function App() {
  // Navigation state
  const [activeTab, setActiveTab] = useState<ActiveTab>('accueil');

  // Accessibility & Comfort Settings (15 to 80+ years old)
  const [fontScalePx, setFontScalePx] = useState<number>(20); // 18px min, 20px default, up to 26px
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [profilePreset, setProfilePreset] = useState<UserProfilePreset>('standard');
  const [learnerLevel, setLearnerLevel] = useState<LearnerLevel>('debutant');
  const [uiLang, setUiLang] = useState<SupportedLanguage>('fr');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isListeningMic, setIsListeningMic] = useState<boolean>(false);

  // Modal for Add Document
  const [showAddDocModal, setShowAddDocModal] = useState<boolean>(false);

  // Core Data State: Professors & Isolated RAG Libraries
  const [professors, setProfessors] = useState<ProfessorConfig[]>(() => {
    const saved = localStorage.getItem('un_professors_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_PROFESSORS;
      }
    }
    return INITIAL_PROFESSORS;
  });

  const [documents, setDocuments] = useState<LibraryDocument[]>(() => {
    const saved = localStorage.getItem('un_documents_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return buildInitialLibraries();
      }
    }
    return buildInitialLibraries();
  });

  const [progress, setProgress] = useState<LearnerProgress>(() => {
    const saved = localStorage.getItem('un_progress_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback below
      }
    }
    return {
      questionsAsked: 2,
      documentsFedToAgents: 10,
      pagesIndexedViaOcr: 24,
      quizzesCompleted: 0,
      quizScoreTotal: 0,
      levelByProfessor: {},
      recentTopics: ['Contrat de travail médical & fiscalité', 'Effet Bohr et oxygénation'],
    };
  });

  // Save state locally (Principle 5: Local privacy by default)
  useEffect(() => {
    localStorage.setItem('un_professors_v1', JSON.stringify(professors));
  }, [professors]);

  useEffect(() => {
    localStorage.setItem('un_documents_v1', JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem('un_progress_v1', JSON.stringify(progress));
  }, [progress]);

  // Consultation State
  const [selectedProfTarget, setSelectedProfTarget] = useState<string>('auto');
  const [trainerSelectedProfId, setTrainerSelectedProfId] = useState<string>('medecine');
  const [questionInput, setQuestionInput] = useState<string>('');
  const [showDetailedAnswer, setShowDetailedAnswer] = useState<boolean>(false);
  const [consultationHistory, setConsultationHistory] = useState<ConsultationResponse[]>(() => [
    orchestrateConsultation({
      question:
        "Quelles sont les règles pour le contrat de travail d'un médecin salarié et comment gérer la trésorerie fiscale d'un cabinet ?",
      professors: INITIAL_PROFESSORS,
      documents: buildInitialLibraries(),
      targetProfessorId: 'auto',
      learnerLevel: 'debutant',
    }),
  ]);

  // Modal for adding a new Professor YAML (Step 3: Modularity)
  const [showAddProfModal, setShowAddProfModal] = useState<boolean>(false);
  const [newProfName, setNewProfName] = useState<string>('');
  const [newProfTitle, setNewProfTitle] = useState<string>('');
  const [newProfSimpleDesc, setNewProfSimpleDesc] = useState<string>('');
  const [newProfKeywords, setNewProfKeywords] = useState<string>('');
  const [newProfInitialDocText, setNewProfInitialDocText] = useState<string>('');

  // Learning / Case Study & Quiz State
  const [selectedCaseStudyId, setSelectedCaseStudyId] = useState<string>(
    PREBUILT_CASE_STUDIES[0].id
  );
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [heroImgError, setHeroImgError] = useState<boolean>(false);

  // Apply profile preset changes
  const handleSelectProfilePreset = (preset: UserProfilePreset) => {
    setProfilePreset(preset);
    if (preset === 'senior') {
      setFontScalePx(22);
      setLearnerLevel('debutant');
    } else if (preset === 'jeune') {
      setFontScalePx(20);
      setLearnerLevel('debutant');
    } else {
      setFontScalePx(20);
      setLearnerLevel('intermediaire');
    }
  };

  // Speech Synthesis (Read Aloud)
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = uiLang === 'ar' ? 'ar-SA' : uiLang === 'en' ? 'en-US' : 'fr-FR';
    utterance.rate = profilePreset === 'senior' ? 0.88 : 1.0;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  // Voice Dictation (Web Speech API)
  const handleVoiceDictation = () => {
    const SpeechRecognitionAPI =
      (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown })
        .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition;

    if (!SpeechRecognitionAPI) {
      setQuestionInput((prev) =>
        prev
          ? prev
          : "Comment fonctionne le contrat de travail d'un médecin et quel budget prévoir ?"
      );
      return;
    }

    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const recognition = new (SpeechRecognitionAPI as any)();
      recognition.lang = uiLang === 'ar' ? 'ar-MA' : uiLang === 'en' ? 'en-US' : 'fr-FR';
      recognition.interimResults = false;
      setIsListeningMic(true);

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognition.onresult = (event: any) => {
        const transcript = event.results?.[0]?.[0]?.transcript || '';
        if (transcript) {
          setQuestionInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
        setIsListeningMic(false);
      };
      recognition.onerror = () => setIsListeningMic(false);
      recognition.onend = () => setIsListeningMic(false);
      recognition.start();
    } catch {
      setIsListeningMic(false);
    }
  };

  // Ask Question Handler
  const handleAskQuestion = (e?: React.FormEvent, customQuestion?: string, customTarget?: string) => {
    if (e) e.preventDefault();
    const q = (customQuestion ?? questionInput).trim();
    if (!q) return;

    const target = customTarget ?? selectedProfTarget;
    const response = orchestrateConsultation({
      question: q,
      professors,
      documents,
      targetProfessorId: target,
      learnerLevel,
    });

    setConsultationHistory((prev) => [response, ...prev]);
    setQuestionInput('');
    setProgress((prev) => ({
      ...prev,
      questionsAsked: prev.questionsAsked + 1,
      recentTopics: [q.slice(0, 60), ...prev.recentTopics.slice(0, 4)],
    }));
  };

  // Add Document from OCR Trainer Window or AddDocumentModule
  const handleAddDocumentToProfessor = (newDoc: LibraryDocument) => {
    setDocuments((prev) => [newDoc, ...prev]);
    setProgress((prev) => ({
      ...prev,
      documentsFedToAgents: prev.documentsFedToAgents + 1,
      pagesIndexedViaOcr: prev.pagesIndexedViaOcr + newDoc.pageCount,
    }));
  };

  const handleDeleteDocument = (docId: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== docId));
  };

  // Add a New Professor via YAML configuration (Step 3 Modularity)
  const handleCreateNewProfessorYaml = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProfName.trim() || !newProfTitle.trim()) return;

    const idSlug = newProfName
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]/g, '_')
      .slice(0, 18);

    const uniqueId = `${idSlug}_${professors.length + 1}`;
    const keywordsList = newProfKeywords
      .split(',')
      .map((k) => k.trim().toLowerCase())
      .filter(Boolean);

    const newProf: ProfessorConfig = {
      id: uniqueId,
      nom_affiche: newProfName.trim(),
      titre: newProfTitle.trim(),
      discipline_courte: newProfTitle.replace(/^Professeure?\s+(de\s+|d')?/i, '').trim(),
      avatar_initials: newProfName
        .trim()
        .split(/\s+/)
        .map((w) => w[0])
        .join('')
        .toUpperCase()
        .slice(0, 2),
      langues: ['fr', 'ar', 'en'],
      description_simple:
        newProfSimpleDesc.trim() ||
        `Spécialiste dédié à la discipline ${newProfTitle.trim()}.`,
      ton: 'Pédagogue, précis et bienveillant',
      niveau_par_defaut: 'debutant',
      bibliotheque: `libraries/${uniqueId}/`,
      modele_teacher: `checkpoints/teacher_${uniqueId}.pt`,
      outils_autorises: ['rag_search', 'citation_verifier'],
      avertissement: '',
      sujets_hors_perimetre: [],
      keywords: keywordsList.length > 0 ? keywordsList : [idSlug],
      system_prompt: `Tu es ${newProfName.trim()}, ${newProfTitle.trim()} de l'Université Numérique. Réponds uniquement à partir de ta bibliothèque (${uniqueId}) avec citation de la page.`,
      yaml_raw: `id: ${uniqueId}
nom_affiche: "${newProfName.trim()}"
titre: "${newProfTitle.trim()}"
description_simple: "${newProfSimpleDesc.trim()}"
langues: [fr, ar, en]
niveau_par_defaut: debutant
bibliotheque: libraries/${uniqueId}/`,
    };

    setProfessors((prev) => [...prev, newProf]);

    if (newProfInitialDocText.trim()) {
      const initialDoc = {
        professorId: uniqueId,
        title: `Manuel Fondamental — ${newProfTitle.trim()}`,
        authorOrSource: 'Ajouté via configuration YAML',
        rawText: `[Page 1]\n${newProfInitialDocText.trim()}`,
      };
      import('./utils/ragAndOcrEngine').then(({ buildDocumentFromOcrOrText }) => {
        const built = buildDocumentFromOcrOrText(initialDoc);
        handleAddDocumentToProfessor(built);
      });
    }

    setNewProfName('');
    setNewProfTitle('');
    setNewProfSimpleDesc('');
    setNewProfKeywords('');
    setNewProfInitialDocText('');
    setShowAddProfModal(false);
  };

  // Export or Reset User Local Data (Step 9: GDPR / Loi 09-08 1-click privacy control)
  const handleExportUserData = () => {
    const payload = {
      application: 'Université Numérique (NeuroDistill)',
      creators: 'Tarik Badri & Larbi Badri',
      exportedAt: new Date().toISOString(),
      progress,
      customProfessorsCount: professors.length,
      documentsCount: documents.length,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'universite_numerique_mes_donnees.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleResetAllLocalData = () => {
    localStorage.removeItem('un_professors_v1');
    localStorage.removeItem('un_documents_v1');
    localStorage.removeItem('un_progress_v1');
    setProfessors(INITIAL_PROFESSORS);
    setDocuments(buildInitialLibraries());
    setProgress({
      questionsAsked: 0,
      documentsFedToAgents: INITIAL_PROFESSORS.length,
      pagesIndexedViaOcr: 24,
      quizzesCompleted: 0,
      quizScoreTotal: 0,
      levelByProfessor: {},
      recentTopics: [],
    });
  };

  const latestConsultation = consultationHistory[0];
  const activeCaseStudy =
    PREBUILT_CASE_STUDIES.find((c) => c.id === selectedCaseStudyId) ||
    PREBUILT_CASE_STUDIES[0];

  return (
    <div
      dir={uiLang === 'ar' ? 'rtl' : 'ltr'}
      style={{ fontSize: `${fontScalePx}px` }}
      className={
        darkMode
          ? 'dark min-h-screen bg-[#0F172A] text-[#F8FAFC]'
          : 'min-h-screen bg-[#F8FAFC] text-[#0F172A]'
      }
    >
      {/* STRICT 3-ZONE TOP BAR CONTRACT */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur border-b border-slate-200 dark:border-slate-800 px-6 py-4">
        <div className="max-w-[1380px] mx-auto flex items-center justify-between gap-8">
          {/* Zone 1: Single text element wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('accueil')}
            className="text-xl font-bold tracking-tight text-slate-900 dark:text-white font-display whitespace-nowrap shrink-0 cursor-pointer"
          >
            Université Numérique
          </button>

          {/* Zone 2: 5 concise single-line navigation links */}
          <nav
            aria-label="Navigation principale"
            className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300"
          >
            <button
              type="button"
              onClick={() => setActiveTab('accueil')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activeTab === 'accueil'
                  ? 'text-sky-700 dark:text-sky-400 underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              Accueil
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('consultation')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activeTab === 'consultation'
                  ? 'text-sky-700 dark:text-sky-400 underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              Poser une question
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('trainer_ocr')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activeTab === 'trainer_ocr'
                  ? 'text-sky-700 dark:text-sky-400 underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              Donner à lire (OCR)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('apprentissage')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activeTab === 'apprentissage'
                  ? 'text-sky-700 dark:text-sky-400 underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              Cas Pratiques &amp; Quiz
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('distillation')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activeTab === 'distillation'
                  ? 'text-sky-700 dark:text-sky-400 underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              Windows / macOS &amp; Distillation
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setShowAddDocModal(true)}
              className="min-h-[44px] px-4 py-2 text-xs font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-2 shadow-sm"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Ajouter un document</span>
            </button>
          </div>
        </div>
      </header>

      {/* Secondary Universal Accessibility Bar (15 to 80+ years old: A+/A-, Profiles, Voice, Language) */}
      <div className="bg-slate-100/80 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800 px-6 py-2.5">
        <div className="max-w-[1380px] mx-auto flex flex-wrap items-center justify-between gap-4 text-xs">
          {/* Mobile visible tab selector + Creators credit */}
          <div className="flex flex-wrap items-center gap-3 text-slate-600 dark:text-slate-300">
            <span className="font-medium">
              Créé par Tarik Badri — en association avec Larbi Badri
            </span>
            <span aria-hidden="true">·</span>
            <span>Réf. scientifique : Mghabbar &amp; Ratnamogan (ECAI 2020)</span>
          </div>

          {/* Universal Comfort Controls */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Profile Switcher: Jeune (15+) / Standard / Senior (80+) */}
            <div
              role="group"
              aria-label="Profil de confort"
              className="flex items-center bg-white dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700"
            >
              <button
                type="button"
                onClick={() => handleSelectProfilePreset('jeune')}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  profilePreset === 'jeune'
                    ? 'bg-sky-700 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Jeune (15+)
              </button>
              <button
                type="button"
                onClick={() => handleSelectProfilePreset('standard')}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  profilePreset === 'standard'
                    ? 'bg-sky-700 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Standard
              </button>
              <button
                type="button"
                onClick={() => handleSelectProfilePreset('senior')}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  profilePreset === 'senior'
                    ? 'bg-sky-700 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Senior (Confort+)
              </button>
            </div>

            {/* Font Size A- / A+ */}
            <div className="flex items-center bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 overflow-hidden tabular-nums">
              <button
                type="button"
                onClick={() => setFontScalePx((s) => Math.max(18, s - 2))}
                title="Réduire la taille du texte"
                className="px-2.5 py-1 font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
              >
                A-
              </button>
              <span className="px-2 text-slate-500 dark:text-slate-400">
                {fontScalePx}px
              </span>
              <button
                type="button"
                onClick={() => setFontScalePx((s) => Math.min(26, s + 2))}
                title="Agrandir la taille du texte"
                className="px-2.5 py-1 font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
              >
                A+
              </button>
            </div>

            {/* Language Selector FR / AR / EN */}
            <div className="flex items-center bg-white dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
              {(['fr', 'ar', 'en'] as SupportedLanguage[]).map((lang) => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => setUiLang(lang)}
                  className={`px-2 py-1 rounded font-medium uppercase cursor-pointer ${
                    uiLang === lang
                      ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {lang === 'fr' ? 'FR' : lang === 'ar' ? 'عربي' : 'EN'}
                </button>
              ))}
            </div>

            {/* Dark / High-Contrast Toggle */}
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-1.5 cursor-pointer"
            >
              {darkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              <span>{darkMode ? 'Mode Clair' : 'Mode Sombre'}</span>
            </button>

            {isSpeaking && (
              <button
                type="button"
                onClick={stopSpeaking}
                className="px-2.5 py-1.5 rounded-lg bg-amber-600 text-white font-semibold flex items-center gap-1 cursor-pointer"
              >
                <VolumeX className="w-3.5 h-3.5" />
                <span>Arrêter la voix</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Quick Navigation Bar (No hidden hamburger menu as required by Step 7) */}
        <div className="flex md:hidden flex-wrap gap-2 mt-2 pt-2 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab('accueil')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold ${
              activeTab === 'accueil'
                ? 'bg-sky-700 text-white'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200'
            }`}
          >
            Accueil
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('consultation')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold ${
              activeTab === 'consultation'
                ? 'bg-sky-700 text-white'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200'
            }`}
          >
            Poser une question
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('trainer_ocr')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold ${
              activeTab === 'trainer_ocr'
                ? 'bg-sky-700 text-white'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200'
            }`}
          >
            Donner à lire (OCR)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('apprentissage')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold ${
              activeTab === 'apprentissage'
                ? 'bg-sky-700 text-white'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200'
            }`}
          >
            Cas &amp; Quiz
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('distillation')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold ${
              activeTab === 'distillation'
                ? 'bg-sky-700 text-white'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200'
            }`}
          >
            Windows / macOS
          </button>
        </div>
      </div>

      {/* MAIN WORKSPACE CONTAINER */}
      <main className="max-w-[1380px] mx-auto px-6 py-8 lg:py-10 space-y-12">
        {/* =====================================================================
            TAB 1: ACCUEIL (3 GROS BOUTONS D'ACTION + GRILLE DES 10 PROFESSEURS)
        ===================================================================== */}
        {activeTab === 'accueil' && (
          <div className="space-y-12">
            {/* Hero Split (2-column balanced stretch) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-10">
              <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <p className="text-sm font-medium text-sky-700 dark:text-sky-400">
                    Université Numérique (NeuroDistill) · Windows, macOS &amp; Web Local
                  </p>
                  <h1 className="text-3xl lg:text-4xl font-bold text-slate-900 dark:text-white leading-tight">
                    Dix Professeurs Numériques qui lisent vos documents et unissent leurs expertises pour vous répondre simplement.
                  </h1>
                  <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                    Conçue par{' '}
                    <strong className="font-semibold text-slate-900 dark:text-white">
                      Tarik Badri
                    </strong>{' '}
                    et{' '}
                    <strong className="font-semibold text-slate-900 dark:text-white">
                      Larbi Badri
                    </strong>
                    , l’Université Numérique met à votre disposition un agent spécialisé par
                    discipline. Donnez-leur vos livres et PDF à lire : ils répondent avec le
                    document et la page exacte, ou disent honnêtement « Je ne sais pas ».
                  </p>
                </div>

                {/* The 3 Big Primary Action Buttons required by Step 7 */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => setActiveTab('consultation')}
                    className="min-h-[84px] p-4 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-left transition-colors flex flex-col justify-between cursor-pointer"
                  >
                    <MessageSquare className="w-6 h-6 mb-2" />
                    <div>
                      <div className="font-bold text-base">1. Poser une question</div>
                      <div className="text-xs text-sky-100 mt-0.5">
                        Par écrit ou à la voix
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowAddDocModal(true)}
                    className="min-h-[84px] p-4 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-left transition-colors flex flex-col justify-between cursor-pointer shadow-sm"
                  >
                    <Upload className="w-6 h-6 text-sky-400 mb-2" />
                    <div>
                      <div className="font-bold text-base">2. Ajouter un document</div>
                      <div className="text-xs text-slate-300 mt-0.5">
                        PDF/Texte · OCR &amp; Assignation
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('apprentissage')}
                    className="min-h-[84px] p-4 rounded-xl bg-slate-100 dark:bg-slate-800/60 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-900 dark:text-white border border-slate-300 dark:border-slate-700 text-left transition-colors flex flex-col justify-between cursor-pointer"
                  >
                    <GraduationCap className="w-6 h-6 text-sky-700 dark:text-sky-400 mb-2" />
                    <div>
                      <div className="font-bold text-base">3. Apprendre un sujet</div>
                      <div className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                        Cas pratiques &amp; quiz
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              <div className="lg:col-span-5 relative rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 min-h-[280px]">
                {!heroImgError ? (
                  <img
                    src={HERO_UNIVERSITY_IMAGE}
                    alt="Grande bibliothèque lumineuse de l'Université Numérique"
                    referrerPolicy="no-referrer"
                    onError={() => setHeroImgError(true)}
                    className="w-full lg:h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
                    <GraduationCap className="w-12 h-12 text-sky-700 mb-3" />
                    <span className="font-semibold">Université Numérique — NeuroDistill</span>
                  </div>
                )}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent p-5 text-white">
                  <p className="text-xs font-medium">
                    Fonctionnement local sur CPU (Windows &amp; macOS) · Zéro donnée simulée
                  </p>
                </div>
              </div>
            </div>

            {/* Full-Width 4-Column Measured Metrics Strip below the Hero Split */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 tabular-nums">
              <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <div className="text-2xl font-bold text-slate-900 dark:text-white">
                  {professors.length} Professeurs
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  1 agent spécialisé par discipline (YAML)
                </div>
              </div>
              <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <div className="text-2xl font-bold text-slate-900 dark:text-white">
                  {documents.length} Ouvrages actifs
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  {progress.pagesIndexedViaOcr} pages indexées avec citation exacte
                </div>
              </div>
              <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <div className="text-2xl font-bold text-slate-900 dark:text-white">
                  {latestConsultation?.measuredLatencyMs ?? 1.8} ms
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Latence réelle mesurée de la dernière synthèse
                </div>
              </div>
              <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
                <div className="text-sm font-bold text-slate-900 dark:text-white">
                  Pack Desktop Windows &amp; macOS
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('distillation')}
                  className="text-xs font-semibold text-sky-700 dark:text-sky-400 hover:underline flex items-center gap-1 mt-1 cursor-pointer"
                >
                  <span>Télécharger run_windows.bat / run_mac.sh</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Directory of the 10+ Digital Professors */}
            <section aria-labelledby="professors-grid-heading" className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2
                    id="professors-grid-heading"
                    className="text-2xl font-bold text-slate-900 dark:text-white"
                  >
                    Vos {professors.length} Professeurs Numériques Spécialisés
                  </h2>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Cliquez sur un professeur pour lui poser une question ou lui donner de nouveaux documents à lire.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setShowAddDocModal(true)}
                    className="min-h-[48px] px-4 py-2.5 rounded-lg bg-sky-700 hover:bg-sky-800 text-sm font-semibold text-white flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer shadow-sm"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Ajouter un document</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowAddProfModal(true)}
                    className="min-h-[48px] px-4 py-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 hover:border-sky-600 text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Plus className="w-4 h-4 text-sky-700 dark:text-sky-400" />
                    <span>Nouveau Professeur (YAML)</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {professors.map((prof) => {
                  const profDocs = documents.filter((d) => d.professorId === prof.id);
                  const totalChunks = profDocs.reduce((s, d) => s + d.chunks.length, 0);
                  return (
                    <div
                      key={prof.id}
                      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 flex flex-col justify-between space-y-5"
                    >
                      <div className="space-y-3">
                        <div className="flex items-center gap-3.5">
                          <div className="w-12 h-12 rounded-xl bg-sky-700 text-white font-bold text-base flex items-center justify-center shrink-0">
                            {prof.avatar_initials}
                          </div>
                          <div>
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                              {prof.nom_affiche}
                            </h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400">
                              {prof.titre}
                            </p>
                          </div>
                        </div>

                        <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                          {prof.description_simple}
                        </p>
                      </div>

                      <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                        <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                          <span>{profDocs.length} ouvrage(s)</span>
                          <span className="mx-1.5" aria-hidden="true">·</span>
                          <span>{totalChunks} passages indexés</span>
                          <span className="mx-1.5" aria-hidden="true">·</span>
                          <span>Langues : {prof.langues.join(', ').toUpperCase()}</span>
                        </div>

                        <div className="flex items-center gap-2.5">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedProfTarget(prof.id);
                              setActiveTab('consultation');
                            }}
                            className="flex-1 min-h-[44px] px-3 py-2 rounded-lg bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold transition-colors cursor-pointer"
                          >
                            Consulter {prof.nom_affiche}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setTrainerSelectedProfId(prof.id);
                              setActiveTab('trainer_ocr');
                            }}
                            className="min-h-[44px] px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer"
                          >
                            Lui donner à lire
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          </div>
        )}

        {/* =====================================================================
            TAB 2: POSER UNE QUESTION (ORCHESTRATEUR TRANSDISCIPLINAIRE & RAG)
        ===================================================================== */}
        {activeTab === 'consultation' && (
          <section className="space-y-8" aria-labelledby="consultation-heading">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-6">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                  <h1
                    id="consultation-heading"
                    className="text-2xl lg:text-3xl font-bold text-slate-900 dark:text-white"
                  >
                    Salon de Consultation &amp; Orchestrateur Transdisciplinaire
                  </h1>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Choisissez « Orchestrateur Automatique » pour mobiliser plusieurs professeurs
                    en même temps, ou interrogez un professeur précis.
                  </p>
                </div>

                {/* Learner Level Selector */}
                <div className="flex items-center gap-2 text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">
                    Niveau d’explication :
                  </span>
                  <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                    {(['debutant', 'intermediaire', 'expert'] as LearnerLevel[]).map((lvl) => (
                      <button
                        key={lvl}
                        type="button"
                        onClick={() => setLearnerLevel(lvl)}
                        className={`px-3 py-1.5 rounded-md font-semibold capitalize transition-colors cursor-pointer ${
                          learnerLevel === lvl
                            ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                            : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {lvl === 'debutant'
                          ? 'Simple (Débutant)'
                          : lvl === 'intermediaire'
                          ? 'Intermédiaire'
                          : 'Précis (Expert)'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Professor Routing Bar */}
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedProfTarget('auto')}
                  className={`min-h-[44px] px-4 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    selectedProfTarget === 'auto'
                      ? 'bg-sky-700 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  Orchestrateur Transdisciplinaire (Routage Automatique)
                </button>
                {professors.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedProfTarget(p.id)}
                    className={`min-h-[44px] px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                      selectedProfTarget === p.id
                        ? 'bg-sky-700 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    {p.nom_affiche} ({p.discipline_courte})
                  </button>
                ))}
              </div>

              {/* Sample Transdisciplinary & Safety Questions */}
              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Questions exemples en 1 clic :
                </p>
                <div className="flex flex-wrap gap-2">
                  {[
                    {
                      label: 'Contrat de travail d’un médecin + Fiscalité (Multi-professeurs)',
                      q: "Quelles clauses faut-il dans le contrat de travail d'un médecin salarié et comment gérer la fiscalité et la trésorerie ?",
                      target: 'auto',
                    },
                    {
                      label: 'Effet Bohr et oxygène dans le sang (Médecine)',
                      q: "Comment fonctionne l'effet Bohr pour libérer l'oxygène de l'hémoglobine vers les muscles ?",
                      target: 'medecine',
                    },
                    {
                      label: 'Calcul du TAEG et budget 50/30/20 (Finance)',
                      q: 'Comment fonctionne la règle budgétaire 50/30/20 et que comprend le TAEG pour un crédit ?',
                      target: 'finance',
                    },
                    {
                      label: 'Question hors bibliothèque → Test « Je ne sais pas »',
                      q: 'Quelle est la composition minéralogique exacte des anneaux de Saturne ?',
                      target: 'droit',
                    },
                  ].map((sample) => (
                    <button
                      key={sample.label}
                      type="button"
                      onClick={() => {
                        setSelectedProfTarget(sample.target);
                        handleAskQuestion(undefined, sample.q, sample.target);
                      }}
                      className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 hover:border-sky-600 text-xs text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
                    >
                      {sample.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Question Input Form with Voice Dictation */}
              <form onSubmit={(e) => handleAskQuestion(e)} className="space-y-3">
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="text"
                    value={questionInput}
                    onChange={(e) => setQuestionInput(e.target.value)}
                    placeholder="Écrivez votre question ici avec vos propres mots..."
                    className="flex-1 min-h-[54px] px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={handleVoiceDictation}
                      title="Dicter ma question à la voix"
                      className={`min-h-[54px] px-4 py-3 rounded-xl border font-semibold text-sm flex items-center gap-2 cursor-pointer ${
                        isListeningMic
                          ? 'bg-red-600 text-white border-red-600'
                          : 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      <Mic className="w-5 h-5" />
                      <span>{isListeningMic ? 'Écoute...' : 'Dicter'}</span>
                    </button>

                    <button
                      type="submit"
                      className="min-h-[54px] px-6 py-3 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-semibold text-sm flex items-center gap-2 cursor-pointer"
                    >
                      <Send className="w-5 h-5" />
                      <span>Demander</span>
                    </button>
                  </div>
                </div>
              </form>
            </div>

            {/* Latest Consultation Result */}
            {latestConsultation && (
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-6">
                {latestConsultation.emergencyTriggered && (
                  <div
                    role="alert"
                    className="p-5 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-300 dark:border-red-800 text-red-900 dark:text-red-100 flex items-start gap-3.5"
                  >
                    <ShieldAlert className="w-6 h-6 text-red-600 shrink-0 mt-0.5" />
                    <div className="space-y-1 text-sm">
                      <div className="font-bold">
                        Garde-fou d’urgence médicale et de sécurité
                      </div>
                      <p>{latestConsultation.emergencyMessage}</p>
                    </div>
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
                  <div className="space-y-1">
                    <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                      <span>
                        {latestConsultation.isTransdisciplinary
                          ? `Synthèse Transdisciplinaire (${latestConsultation.selectedProfessors.length} professeurs mobilisés)`
                          : `Réponse disciplinaire de ${latestConsultation.selectedProfessors[0]?.professorName}`}
                      </span>
                      <span className="mx-2" aria-hidden="true">·</span>
                      <span>Latence réelle mesurée : {latestConsultation.measuredLatencyMs} ms</span>
                      <span className="mx-2" aria-hidden="true">·</span>
                      <span>{latestConsultation.allCitations.length} source(s) citée(s)</span>
                    </div>
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                      « {latestConsultation.question} »
                    </h2>
                  </div>

                  {/* Step 7 Voice & Progressive Disclosure Controls */}
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        speakText(
                          showDetailedAnswer
                            ? latestConsultation.synthesizedAnswerDetailed
                            : latestConsultation.synthesizedAnswerSimple
                        )
                      }
                      className="min-h-[44px] px-4 py-2 rounded-lg bg-sky-700 hover:bg-sky-800 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span>Écouter la réponse</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setShowDetailedAnswer((prev) => !prev)}
                      className="min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      {showDetailedAnswer ? 'Expliquer plus simplement' : 'Plus de détails'}
                    </button>
                  </div>
                </div>

                {/* Main Synthesized Answer */}
                <div className="p-5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 whitespace-pre-line leading-relaxed text-slate-900 dark:text-slate-100">
                  {showDetailedAnswer
                    ? latestConsultation.synthesizedAnswerDetailed
                    : latestConsultation.synthesizedAnswerSimple}
                </div>

                {/* If any Professor didn't know, offer 1-click button to feed them a document */}
                {latestConsultation.selectedProfessors.some((p) => !p.knownInLibrary) && (
                  <div className="p-4 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="text-sm text-amber-900 dark:text-amber-200">
                      Ce sujet ne figure pas encore dans la bibliothèque de ce professeur.
                      Donnez-lui un document à lire pour qu’il devienne compétent sur ce point !
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowAddDocModal(true)}
                      className="min-h-[44px] px-4 py-2 rounded-lg bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Ajouter un document</span>
                    </button>
                  </div>
                )}

                {/* Clickable Verifiable Sources from the Professors' Libraries */}
                {latestConsultation.allCitations.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                      Sources documentaires vérifiées dans les bibliothèques :
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {latestConsultation.allCitations.map((cit, idx) => (
                        <div
                          key={`${cit.documentId}_${idx}`}
                          className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 space-y-2"
                        >
                          <div className="text-xs font-semibold text-sky-700 dark:text-sky-400 tabular-nums">
                            {cit.professorName} · « {cit.documentTitle} » · Page {cit.pageNumber}
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                            « {cit.excerpt} »
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </section>
        )}

        {/* =====================================================================
            TAB 3: FENÊTRE « DONNER À LIRE À MES AGENTS » (STUDIO OCR & RAG)
        ===================================================================== */}
        {activeTab === 'trainer_ocr' && (
          <AgentDocumentTrainerWindow
            professors={professors}
            documents={documents}
            selectedProfessorId={trainerSelectedProfId}
            onSelectProfessor={setTrainerSelectedProfId}
            onAddDocument={handleAddDocumentToProfessor}
            onDeleteDocument={handleDeleteDocument}
            onJumpToConsultationWithQuestion={(profId, q) => {
              setSelectedProfTarget(profId);
              handleAskQuestion(undefined, q, profId);
              setActiveTab('consultation');
            }}
            learnerLevel={learnerLevel}
            speakText={speakText}
            ocrHeroImage={OCR_STUDIO_IMAGE}
          />
        )}

        {/* =====================================================================
            TAB 4: CAS PRATIQUES TRANSDISCIPLINAIRES, QUIZ & VIE PRIVÉE
        ===================================================================== */}
        {activeTab === 'apprentissage' && (
          <div className="space-y-10">
            {/* Guided Case Study Mode */}
            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
                    Mode « Cas Pratique » Transdisciplinaire
                  </h1>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    L’Orchestrateur découpe un projet concret de la vie réelle en plan d’action par spécialité.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  {PREBUILT_CASE_STUDIES.map((cs) => (
                    <button
                      key={cs.id}
                      type="button"
                      onClick={() => setSelectedCaseStudyId(cs.id)}
                      className={`min-h-[44px] px-3.5 py-2 rounded-lg text-xs font-semibold cursor-pointer ${
                        selectedCaseStudyId === cs.id
                          ? 'bg-sky-700 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {cs.scenarioTitle}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                  Situation analysée · Temps de découpage mesuré : {activeCaseStudy.measuredLatencyMs} ms
                </div>
                <p className="font-semibold text-slate-900 dark:text-white">
                  « {activeCaseStudy.userDescription} »
                </p>
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  {activeCaseStudy.transdisciplinarySummary}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {activeCaseStudy.steps.map((step) => (
                  <div
                    key={step.stepNumber}
                    className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 space-y-2.5"
                  >
                    <div className="text-xs font-semibold text-sky-700 dark:text-sky-400 tabular-nums">
                      Étape 0{step.stepNumber} · {step.discipline} · {step.professorName}
                    </div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {step.subQuestion}
                    </h3>
                    <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                      {step.actionableAdvice}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 pt-1">
                      Source : {step.sourceCitation}
                    </p>
                  </div>
                ))}
              </div>
            </section>

            {/* Quiz Verified from Libraries */}
            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 lg:p-8 space-y-6">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                  Quiz de Révision Ancré dans les Bibliothèques
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Vérifiez vos acquis. Chaque explication renvoie à la page source du professeur.
                </p>
              </div>

              <div className="space-y-6">
                {INITIAL_QUIZ_QUESTIONS.map((q, qIdx) => {
                  const chosen = quizAnswers[q.id];
                  return (
                    <div
                      key={q.id}
                      className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-3"
                    >
                      <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
                        Question {qIdx + 1} · Proposée par {q.professorName}
                      </div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white">
                        {q.question}
                      </h3>
                      <div className="space-y-2">
                        {q.options.map((opt, oIdx) => {
                          const isSelected = chosen === oIdx;
                          const isCorrect = q.correctIndex === oIdx;
                          return (
                            <button
                              key={opt}
                              type="button"
                              onClick={() =>
                                setQuizAnswers((prev) => ({ ...prev, [q.id]: oIdx }))
                              }
                              className={`w-full min-h-[48px] p-3.5 rounded-lg border text-left text-sm transition-colors flex items-center justify-between gap-3 cursor-pointer ${
                                quizSubmitted && isCorrect
                                  ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-600 text-emerald-950 dark:text-emerald-100 font-semibold'
                                  : isSelected
                                  ? 'bg-sky-700 text-white border-sky-700 font-medium'
                                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200'
                              }`}
                            >
                              <span>{opt}</span>
                              {quizSubmitted && isCorrect && (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {quizSubmitted && (
                        <div className="p-3.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs space-y-1">
                          <p className="font-semibold text-slate-900 dark:text-white">
                            Explication : {q.explanation}
                          </p>
                          <p className="text-slate-500">Source : {q.sourceCitation}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => {
                    setQuizSubmitted(true);
                    const correctCount = INITIAL_QUIZ_QUESTIONS.filter(
                      (q) => quizAnswers[q.id] === q.correctIndex
                    ).length;
                    setProgress((prev) => ({
                      ...prev,
                      quizzesCompleted: prev.quizzesCompleted + 1,
                      quizScoreTotal: prev.quizScoreTotal + correctCount,
                    }));
                  }}
                  className="min-h-[48px] px-6 py-2.5 rounded-lg bg-sky-700 hover:bg-sky-800 text-white font-semibold text-sm cursor-pointer"
                >
                  Vérifier mes réponses
                </button>
                {quizSubmitted && (
                  <button
                    type="button"
                    onClick={() => {
                      setQuizSubmitted(false);
                      setQuizAnswers({});
                    }}
                    className="min-h-[48px] px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-sm font-medium cursor-pointer"
                  >
                    Recommencer le quiz
                  </button>
                )}
              </div>
            </section>

            {/* Step 9 Local Privacy & GDPR / Loi 09-08 Control */}
            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Vie Privée &amp; Souveraineté des Données (RGPD / Loi 09-08 Maroc)
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Toutes vos progressions et bibliothèques ajoutées sont stockées localement sur votre appareil.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3 shrink-0">
                <button
                  type="button"
                  onClick={handleExportUserData}
                  className="min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Exporter mes données (JSON)</span>
                </button>
                <button
                  type="button"
                  onClick={handleResetAllLocalData}
                  className="min-h-[44px] px-4 py-2 rounded-lg border border-red-300 dark:border-red-800 text-red-700 dark:text-red-400 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Réinitialiser les données locales</span>
                </button>
              </div>
            </section>
          </div>
        )}

        {/* =====================================================================
            TAB 5: WINDOWS / MACOS & DISTILLATION (STEP 1, 2, 6, 10, 11)
        ===================================================================== */}
        {activeTab === 'distillation' && (
          <DistillationAndExportStudio distillDiagramImage={DISTILL_DIAGRAM_IMAGE} />
        )}
      </main>

      {/* Modal: ADD DOCUMENT (PDF / Text upload + Indra OCR + Auto-assignment + Live progress) */}
      {showAddDocModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-doc-modal-title"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6"
        >
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl relative">
            <AddDocumentModule
              professors={professors}
              documents={documents}
              onDocumentAdded={handleAddDocumentToProfessor}
              onOpenConsultationWithQuestion={(profId, q) => {
                setShowAddDocModal(false);
                setSelectedProfTarget(profId);
                handleAskQuestion(undefined, q, profId);
                setActiveTab('consultation');
              }}
              learnerLevel={learnerLevel}
              speakText={speakText}
              isModal
              onClose={() => setShowAddDocModal(false)}
            />
          </div>
        </div>
      )}

      {/* Modal: Add a New Professor via YAML Config (Step 3 Modularity) */}
      {showAddProfModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-prof-modal-title"
          className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4"
        >
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-xl w-full p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h2
                id="add-prof-modal-title"
                className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2"
              >
                <FilePlus2 className="w-5 h-5 text-sky-700" />
                <span>Ajouter un nouveau Professeur (Fichier YAML)</span>
              </h2>
              <button
                type="button"
                onClick={() => setShowAddProfModal(false)}
                className="text-sm text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
              >
                Fermer
              </button>
            </div>

            <form onSubmit={handleCreateNewProfessorYaml} className="space-y-4 text-sm">
              <div>
                <label className="block font-semibold mb-1">Nom affiché du Professeur</label>
                <input
                  type="text"
                  required
                  value={newProfName}
                  onChange={(e) => setNewProfName(e.target.value)}
                  placeholder="Ex. : Pr Salma"
                  className="w-full min-h-[44px] px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Titre &amp; Spécialité</label>
                <input
                  type="text"
                  required
                  value={newProfTitle}
                  onChange={(e) => setNewProfTitle(e.target.value)}
                  placeholder="Ex. : Professeure d’Agronomie & Permaculture"
                  className="w-full min-h-[44px] px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">
                  Description simple (1 phrase claire pour tous les âges)
                </label>
                <input
                  type="text"
                  required
                  value={newProfSimpleDesc}
                  onChange={(e) => setNewProfSimpleDesc(e.target.value)}
                  placeholder="Ex. : Elle t'apprend à cultiver la terre et économiser l'eau d'irrigation."
                  className="w-full min-h-[44px] px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">
                  Mots-clés de routage (séparés par des virgules)
                </label>
                <input
                  type="text"
                  value={newProfKeywords}
                  onChange={(e) => setNewProfKeywords(e.target.value)}
                  placeholder="Ex. : agronomie, sol, irrigation, semence, compost, recolte"
                  className="w-full min-h-[44px] px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">
                  Premier document de sa bibliothèque (optionnel)
                </label>
                <textarea
                  rows={3}
                  value={newProfInitialDocText}
                  onChange={(e) => setNewProfInitialDocText(e.target.value)}
                  placeholder="Collez un premier texte de référence pour initialiser sa bibliothèque..."
                  className="w-full p-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddProfModal(false)}
                  className="min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 rounded-lg bg-sky-700 hover:bg-sky-800 text-white font-semibold cursor-pointer"
                >
                  Enregistrer dans le Registre
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quiet Academic & Software Credits Footer (Step 10) */}
      <footer className="mt-16 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-6 py-8 text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-[1380px] mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              © 2026 Tarik Badri &amp; Larbi Badri — Université Numérique (NeuroDistill)
            </p>
            <p>
              Créé par Tarik Badri — en association avec Larbi Badri. Compatible Windows (.bat),
              macOS (.sh) et Linux en exécution locale CPU.
            </p>
          </div>
          <div className="space-y-1 sm:text-right">
            <p>
              Référence scientifique : Mghabbar &amp; Ratnamogan (ECAI 2020), Multi-Domain Knowledge
              Distillation.
            </p>
            <p>
              Pipeline documentaire : Adaptateur Indra OCR (Datalab ONNX CPU) &amp; RAG hybride isolé
              par professeur.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
