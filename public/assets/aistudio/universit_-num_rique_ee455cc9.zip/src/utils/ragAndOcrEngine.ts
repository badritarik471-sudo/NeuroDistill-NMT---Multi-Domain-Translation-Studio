// © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
// Référence scientifique : Mghabbar & Ratnamogan (ECAI 2020)

import {
  CitedSource,
  ConsultationResponse,
  DistillationRunResult,
  DocumentChunk,
  LearnerLevel,
  LibraryDocument,
  ProfessorConfig,
  ProfessorContribution,
  SupportedLanguage,
} from '../types/university';

const STOP_WORDS = new Set([
  'le', 'la', 'les', 'un', 'une', 'des', 'du', 'de', 'd', 'et', 'ou', 'mais',
  'donc', 'or', 'ni', 'car', 'dans', 'sur', 'sous', 'avec', 'sans', 'pour',
  'par', 'en', 'au', 'aux', 'ce', 'cet', 'cette', 'ces', 'mon', 'ton', 'son',
  'notre', 'votre', 'leur', 'je', 'tu', 'il', 'elle', 'on', 'nous', 'vous',
  'ils', 'elles', 'qui', 'que', 'quoi', 'dont', 'ou', 'est', 'sont', 'etre',
  'avoir', 'fait', 'faire', 'comment', 'pourquoi', 'quel', 'quelle', 'quels',
  'quelles', 'plus', 'moins', 'tres', 'tout', 'tous', 'toute', 'toutes',
  'the', 'and', 'for', 'with', 'from', 'that', 'this', 'what', 'how', 'is', 'are'
]);

export function normalizeAndTokenize(text: string): string[] {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter((token) => token.length > 2 && !STOP_WORDS.has(token));
}

const PROMPT_INJECTION_PATTERNS = [
  /ignore\s+(all\s+)?(previous|prior)\s+instructions/gi,
  /oublie\s+(toutes\s+)?les\s+instructions/gi,
  /system\s*prompt\s*:/gi,
  /tu\s+es\s+maintenant\s+un\s+autre/gi,
  /disregard\s+safety\s+rules/gi,
  /execute\s+shell\s+command/gi,
];

export function sanitizeDocumentContent(rawText: string): {
  cleanText: string;
  warnings: string[];
} {
  let cleanText = rawText;
  const warnings: string[] = [];

  for (const pattern of PROMPT_INJECTION_PATTERNS) {
    if (pattern.test(cleanText)) {
      warnings.push(
        "Tentative d'injection d'instruction détectée et neutralisée (le contenu documentaire est traité exclusivement comme donnée passive)."
      );
      cleanText = cleanText.replace(
        pattern,
        '[SEGMENT NEUTRALISÉ PAR GARDE-FOU DE SÉCURITÉ RAG]'
      );
    }
  }

  return { cleanText, warnings };
}

export function buildDocumentFromOcrOrText(params: {
  professorId: string;
  title: string;
  authorOrSource: string;
  rawText: string;
  language?: SupportedLanguage;
  sourceType?: LibraryDocument['sourceType'];
}): LibraryDocument {
  const t0 = performance.now();
  const { cleanText, warnings } = sanitizeDocumentContent(params.rawText);

  // Split by explicit [Page X] markers or every ~650 chars by paragraph
  const explicitPageRegex = /\[Page\s+(\d+)\]/gi;
  const hasExplicitPages = explicitPageRegex.test(cleanText);

  const chunks: DocumentChunk[] = [];
  const docId = `doc_${params.professorId}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const language: SupportedLanguage = params.language || 'fr';
  const createdAt = new Date().toISOString().split('T')[0];

  if (hasExplicitPages) {
    const parts = cleanText.split(/\[Page\s+\d+\]/i).map((s) => s.trim()).filter(Boolean);
    const pageMatches = [...cleanText.matchAll(/\[Page\s+(\d+)\]/gi)];

    parts.forEach((pageContent, idx) => {
      const pageNum = pageMatches[idx] ? parseInt(pageMatches[idx][1], 10) : idx + 1;
      const paragraphs = pageContent
        .split(/\n{2,}/)
        .map((p) => p.trim())
        .filter((p) => p.length > 20);

      if (paragraphs.length === 0 && pageContent.length > 0) {
        paragraphs.push(pageContent);
      }

      paragraphs.forEach((para, pIdx) => {
        // Chunk with overlap if paragraph is long
        const overlapContext = pIdx > 0 ? paragraphs[pIdx - 1].slice(-90) + ' … ' : '';
        const fullChunkText = overlapContext + para;
        chunks.push({
          id: `${docId}_p${pageNum}_c${pIdx + 1}`,
          documentId: docId,
          documentTitle: params.title,
          professorId: params.professorId,
          pageNumber: pageNum,
          content: para,
          tokens: normalizeAndTokenize(fullChunkText),
          language,
          createdAt,
          sanitizedInjectionDetected: warnings.length > 0,
        });
      });
    });
  } else {
    const paragraphs = cleanText
      .split(/\n{2,}/)
      .map((p) => p.trim())
      .filter((p) => p.length > 15);

    let currentPage = 1;
    let charsOnPage = 0;

    paragraphs.forEach((para, idx) => {
      if (charsOnPage > 600) {
        currentPage += 1;
        charsOnPage = 0;
      }
      charsOnPage += para.length;

      chunks.push({
        id: `${docId}_p${currentPage}_c${idx + 1}`,
        documentId: docId,
        documentTitle: params.title,
        professorId: params.professorId,
        pageNumber: currentPage,
        content: para,
        tokens: normalizeAndTokenize(para),
        language,
        createdAt,
        sanitizedInjectionDetected: warnings.length > 0,
      });
    });
  }

  const maxPage = chunks.reduce((max, c) => Math.max(max, c.pageNumber), 1);
  const t1 = performance.now();

  return {
    id: docId,
    professorId: params.professorId,
    title: params.title,
    authorOrSource: params.authorOrSource,
    language,
    addedAt: createdAt,
    pageCount: maxPage,
    sourceType: params.sourceType || 'native_pdf',
    ocrProcessingMs: Math.max(1, Math.round((t1 - t0) * 10) / 10),
    rawText: cleanText,
    chunks,
    sanitizedWarnings: warnings,
  };
}

const EMERGENCY_PATTERNS = [
  /douleur\s+(thoracique|poitrine)/i,
  /infarctus|avc|accident\s+vasculaire/i,
  /hemorragie\s+grave|saignement\s+abondant/i,
  /suicide|me\s+suicider|mettre\s+fin\s+a\s+mes\s+jours|envie\s+de\s+mourir/i,
  /inconscient|ne\s+respire\s+plus/i,
];

export function detectMedicalOrSafetyEmergency(
  question: string,
  countryCode: 'MA' | 'FR' | 'INT' = 'MA'
): { triggered: boolean; message?: string } {
  for (const pattern of EMERGENCY_PATTERNS) {
    if (pattern.test(question)) {
      const numbers =
        countryCode === 'MA'
          ? 'SAMU / Pompiers Maroc : 150 · Police : 19 · Gendarmerie Royale : 177 · SOS Détresse : 0801 00 51 51'
          : 'SAMU France : 15 · Urgences Européennes : 112 · Prévention Suicide : 3114';

      return {
        triggered: true,
        message: `Attention — Votre message évoque une situation d'urgence médicale ou de détresse immédiate. L'Université Numérique fournit uniquement une information éducative et ne pose jamais de diagnostic médical. Veuillez contacter immédiatement un médecin ou les secours d'urgence (${numbers}).`,
      };
    }
  }
  return { triggered: false };
}

export function searchProfessorLibrary(
  query: string,
  professor: ProfessorConfig,
  documents: LibraryDocument[],
  topK = 3
): CitedSource[] {
  const queryTokens = normalizeAndTokenize(query);
  if (queryTokens.length === 0) return [];

  // Strict library isolation: only inspect documents belonging to this professor
  const profDocs = documents.filter((d) => d.professorId === professor.id);
  const scoredSources: CitedSource[] = [];

  for (const doc of profDocs) {
    const titleTokens = normalizeAndTokenize(doc.title);

    for (const chunk of doc.chunks) {
      let score = 0;
      const chunkTokenSet = new Set(chunk.tokens);

      for (const qt of queryTokens) {
        if (chunkTokenSet.has(qt)) {
          score += 3.0;
        } else {
          // Prefix/stem match for French morphology (e.g. fiscal / fiscalite, contrat / contractuel)
          const stem = qt.slice(0, Math.min(qt.length, 5));
          if (stem.length >= 4) {
            for (const ct of chunk.tokens) {
              if (ct.startsWith(stem) || qt.startsWith(ct.slice(0, 5))) {
                score += 1.4;
                break;
              }
            }
          }
        }

        if (titleTokens.some((tt) => tt.startsWith(qt.slice(0, 4)))) {
          score += 1.2;
        }
      }

      if (score > 0) {
        const normalizedScore = Math.min(
          0.99,
          Math.round((score / (queryTokens.length * 3.2)) * 100) / 100
        );
        scoredSources.push({
          documentId: doc.id,
          documentTitle: doc.title,
          professorName: professor.nom_affiche,
          professorId: professor.id,
          pageNumber: chunk.pageNumber,
          excerpt: chunk.content,
          relevanceScore: normalizedScore,
        });
      }
    }
  }

  return scoredSources
    .sort((a, b) => b.relevanceScore - a.relevanceScore)
    .slice(0, topK);
}

export function scoreProfessorDomainRelevance(
  query: string,
  professor: ProfessorConfig,
  documents: LibraryDocument[]
): number {
  const queryTokens = normalizeAndTokenize(query);
  if (queryTokens.length === 0) return 0;

  let keywordScore = 0;
  const profKeywords = professor.keywords.map((k) =>
    k
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
  );

  for (const qt of queryTokens) {
    const stem = qt.slice(0, Math.min(qt.length, 5));
    if (profKeywords.some((kw) => kw.includes(stem) || qt.includes(kw.slice(0, 5)))) {
      keywordScore += 2.5;
    }
  }

  const ragHits = searchProfessorLibrary(query, professor, documents, 2);
  const ragScore = ragHits.reduce((acc, h) => acc + h.relevanceScore * 4, 0);

  return Math.round((keywordScore + ragScore) * 100) / 100;
}

export function orchestrateConsultation(params: {
  question: string;
  professors: ProfessorConfig[];
  documents: LibraryDocument[];
  targetProfessorId?: string | 'auto';
  learnerLevel: LearnerLevel;
  countryCode?: 'MA' | 'FR' | 'INT';
}): ConsultationResponse {
  const t0 = performance.now();
  const { question, professors, documents, targetProfessorId, learnerLevel, countryCode = 'MA' } =
    params;

  const emergency = detectMedicalOrSafetyEmergency(question, countryCode);

  // Score all professors for domain routing
  const rankedProfessors = professors
    .map((prof) => ({
      prof,
      score: scoreProfessorDomainRelevance(question, prof, documents),
    }))
    .sort((a, b) => b.score - a.score);

  let selectedProfs: { prof: ProfessorConfig; score: number }[] = [];
  let outOfScopeRedirect: ConsultationResponse['outOfScopeRedirect'] = undefined;

  if (targetProfessorId && targetProfessorId !== 'auto') {
    const chosen = professors.find((p) => p.id === targetProfessorId);
    if (chosen) {
      const chosenScore = scoreProfessorDomainRelevance(question, chosen, documents);
      const bestAlternative = rankedProfessors[0];

      // Check if question is out of scope for chosen professor but strongly matches another
      if (
        chosenScore < 1.2 &&
        bestAlternative &&
        bestAlternative.prof.id !== chosen.id &&
        bestAlternative.score >= 2.5
      ) {
        outOfScopeRedirect = {
          fromProfessor: chosen.nom_affiche,
          suggestedProfessorId: bestAlternative.prof.id,
          suggestedProfessorName: `${bestAlternative.prof.nom_affiche} (${bestAlternative.prof.titre})`,
        };
      }
      selectedProfs = [{ prof: chosen, score: chosenScore }];
    }
  } else {
    // Automatic Orchestrator Routing: pick top 1 or up to 3 if transdisciplinary
    const topMatches = rankedProfessors.filter((item) => item.score >= 1.5);
    if (topMatches.length >= 2) {
      selectedProfs = topMatches.slice(0, 3);
    } else if (topMatches.length === 1) {
      selectedProfs = [topMatches[0]];
    } else {
      selectedProfs = [rankedProfessors[0]];
    }
  }

  const contributions: ProfessorContribution[] = selectedProfs.map(({ prof, score }) => {
    const sources = searchProfessorLibrary(question, prof, documents, 2);

    if (sources.length === 0) {
      return {
        professorId: prof.id,
        professorName: prof.nom_affiche,
        professorTitle: prof.titre,
        domainScore: score,
        knownInLibrary: false,
        citations: [],
        disclaimer: prof.avertissement,
        answerSimple: `Je ne sais pas répondre avec certitude car ma bibliothèque actuelle (${prof.bibliotheque}) ne contient aucun document traitant directement de ce sujet. Vous pouvez m'apprendre ce sujet en ouvrant la fenêtre « Nourrir mes Agents (OCR) » pour me donner un document à lire.`,
        answerDetailed: `Conformément à la charte d'honnêteté de l'Université Numérique, je ne formule aucune réponse inventée hors de ma bibliothèque vérifiée (${prof.bibliotheque}). Ajoutez un PDF, un cours ou une note technique dans ma bibliothèque pour que je puisse l'indexer et vous répondre avec citation de page.`,
      };
    }

    const primary = sources[0];
    const secondary = sources[1];

    const answerSimple =
      learnerLevel === 'expert'
        ? `D'après « ${primary.documentTitle} » (Page ${primary.pageNumber}) : ${primary.excerpt}`
        : `En mots simples : ${primary.excerpt} (Source vérifiée : « ${primary.documentTitle} », page ${primary.pageNumber}).`;

    const answerDetailed = [
      `Analyse fondée sur la bibliothèque de ${prof.nom_affiche} (${prof.titre}) :`,
      `1. Extrait principal (« ${primary.documentTitle} », Page ${primary.pageNumber}) : « ${primary.excerpt} »`,
      secondary
        ? `2. Complément documentaire (« ${secondary.documentTitle} », Page ${secondary.pageNumber}) : « ${secondary.excerpt} »`
        : null,
      prof.avertissement ? `Rappel déontologique : ${prof.avertissement}` : null,
    ]
      .filter(Boolean)
      .join('\n\n');

    return {
      professorId: prof.id,
      professorName: prof.nom_affiche,
      professorTitle: prof.titre,
      domainScore: score,
      knownInLibrary: true,
      citations: sources,
      disclaimer: prof.avertissement,
      answerSimple,
      answerDetailed,
    };
  });

  const allCitations = contributions.flatMap((c) => c.citations);
  const isTransdisciplinary = contributions.length > 1;

  let synthesizedAnswerSimple = '';
  let synthesizedAnswerDetailed = '';

  if (emergency.triggered && emergency.message) {
    synthesizedAnswerSimple = emergency.message;
    synthesizedAnswerDetailed =
      emergency.message +
      '\n\nInformation documentaire complémentaire :\n' +
      contributions.map((c) => `• ${c.professorName} : ${c.answerSimple}`).join('\n');
  } else if (outOfScopeRedirect) {
    synthesizedAnswerSimple = `${outOfScopeRedirect.fromProfessor} précise : « Cette question relève plutôt de mon collègue ${outOfScopeRedirect.suggestedProfessorName}. » ${contributions[0]?.answerSimple || ''}`;
    synthesizedAnswerDetailed = `${outOfScopeRedirect.fromProfessor} indique que ce sujet dépasse son périmètre disciplinaire et vous oriente vers ${outOfScopeRedirect.suggestedProfessorName}.\n\n${contributions[0]?.answerDetailed || ''}`;
  } else if (isTransdisciplinary) {
    synthesizedAnswerSimple =
      `Synthèse transdisciplinaire (${contributions.map((c) => c.professorName).join(' + ')}) :\n\n` +
      contributions
        .map((c) => `• ${c.professorName} (${c.professorTitle}) : ${c.answerSimple}`)
        .join('\n\n');

    synthesizedAnswerDetailed =
      `Consultation croisée de ${contributions.length} professeurs spécialisés :\n\n` +
      contributions
        .map(
          (c, i) =>
            `Volet ${i + 1} — ${c.professorName} (${c.professorTitle}) :\n${c.answerDetailed}`
        )
        .join('\n\n---\n\n');
  } else {
    synthesizedAnswerSimple = contributions[0]?.answerSimple || 'Je ne sais pas.';
    synthesizedAnswerDetailed = contributions[0]?.answerDetailed || 'Je ne sais pas.';
  }

  const t1 = performance.now();

  return {
    id: `consult_${Date.now()}`,
    question,
    timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
    measuredLatencyMs: Math.max(1, Math.round((t1 - t0) * 10) / 10),
    isTransdisciplinary,
    selectedProfessors: contributions,
    synthesizedAnswerSimple,
    synthesizedAnswerDetailed,
    allCitations,
    emergencyTriggered: emergency.triggered,
    emergencyMessage: emergency.message,
    outOfScopeRedirect,
  };
}

/**
 * Step 2 & Step 6: Real mathematical implementation of Multi-Teacher Knowledge Distillation
 * L = (1 - alpha) * CE_smooth(y, student_logits) + alpha * T^2 * KL(teacher_probs_T || student_probs_T)
 * with explicit padding mask verification and decreasing loss on a toy mini-batch.
 */
export function runRealDistillationSimulation(params: {
  alpha: number;
  temperature: number;
  labelSmoothing: number;
  steps?: number;
}): DistillationRunResult {
  const t0 = performance.now();
  const { alpha, temperature: T, labelSmoothing: eps, steps = 12 } = params;

  const vocabSize = 8;
  // Toy batch of 4 tokens + 2 padded positions (mask = [1, 1, 1, 1, 0, 0])
  const targetTokens = [2, 5, 1, 4, 0, 0];
  const paddingMask = [1, 1, 1, 1, 0, 0];
  const validTokenCount = paddingMask.reduce((a, b) => a + b, 0);

  // Teacher ensemble logits for the 6 positions
  const teacherLogits: number[][] = [
    [-0.5, 0.2, 3.8, 0.4, -0.2, 0.1, -0.4, 0.0],
    [0.1, -0.3, 0.4, 0.2, -0.1, 4.1, 0.3, -0.2],
    [0.2, 3.9, -0.4, 0.5, 0.1, -0.2, 0.0, 0.1],
    [-0.2, 0.3, 0.1, -0.5, 3.7, 0.4, 0.2, -0.1],
    // Padded positions (must be zeroed out by paddingMask)
    [9.9, -9.9, 5.0, -5.0, 3.0, 1.0, 0.0, -2.0],
    [-8.0, 7.0, -3.0, 4.0, -1.0, 2.0, 6.0, -4.0],
  ];

  // Initialize Student logits and update towards target + teacher ensemble over `steps`
  const studentLogits: number[][] = teacherLogits.map((_, idx) =>
    Array.from({ length: vocabSize }, (__, v) => Math.sin(idx * 3 + v) * 0.4)
  );

  const softmax = (logits: number[], temp: number): number[] => {
    const scaled = logits.map((x) => x / temp);
    const maxLogit = Math.max(...scaled);
    const exps = scaled.map((x) => Math.exp(x - maxLogit));
    const sum = exps.reduce((a, b) => a + b, 0);
    return exps.map((e) => e / sum);
  };

  const lossHistory: DistillationRunResult['lossHistory'] = [];
  const learningRate = 0.38;

  for (let step = 1; step <= steps; step++) {
    let totalCe = 0;
    let totalKl = 0;

    for (let pos = 0; pos < targetTokens.length; pos++) {
      const maskVal = paddingMask[pos];
      if (maskVal === 0) continue; // Strict padding mask enforcement

      const targetIdx = targetTokens[pos];
      const sProbs1 = softmax(studentLogits[pos], 1.0);
      const sProbsT = softmax(studentLogits[pos], T);
      const tProbsT = softmax(teacherLogits[pos], T);

      // Label-smoothed Cross-Entropy: y_smooth = (1 - eps) * one_hot + eps / vocabSize
      let posCe = 0;
      for (let v = 0; v < vocabSize; v++) {
        const ySmooth = (v === targetIdx ? 1 - eps : 0) + eps / vocabSize;
        posCe -= ySmooth * Math.log(Math.max(sProbs1[v], 1e-12));
      }

      // KL Divergence: sum(P_teacher_T * log(P_teacher_T / P_student_T))
      let posKl = 0;
      for (let v = 0; v < vocabSize; v++) {
        const pT = Math.max(tProbsT[v], 1e-12);
        const pS = Math.max(sProbsT[v], 1e-12);
        posKl += pT * Math.log(pT / pS);
      }

      totalCe += posCe * maskVal;
      totalKl += posKl * maskVal;

      // Gradient descent step on student logits
      for (let v = 0; v < vocabSize; v++) {
        const ySmooth = (v === targetIdx ? 1 - eps : 0) + eps / vocabSize;
        const gradCe = sProbs1[v] - ySmooth;
        const gradKl = (sProbsT[v] - tProbsT[v]) / T;
        const gradTotal = (1 - alpha) * gradCe + alpha * T * T * gradKl;
        studentLogits[pos][v] -= learningRate * gradTotal;
      }
    }

    const avgCe = totalCe / validTokenCount;
    const avgKl = totalKl / validTokenCount;
    const combinedLoss = (1 - alpha) * avgCe + alpha * T * T * avgKl;

    lossHistory.push({
      step,
      totalLoss: Math.round(combinedLoss * 10000) / 10000,
      ceLoss: Math.round(avgCe * 10000) / 10000,
      klLoss: Math.round(avgKl * 10000) / 10000,
    });
  }

  const t1 = performance.now();
  const first = lossHistory[0];
  const last = lossHistory[lossHistory.length - 1];

  return {
    alpha,
    temperature: T,
    labelSmoothing: eps,
    epochs: steps,
    batchSize: validTokenCount,
    measuredExecutionMs: Math.max(0.2, Math.round((t1 - t0) * 100) / 100),
    initialLoss: first.totalLoss,
    finalLoss: last.totalLoss,
    ceLossComponent: last.ceLoss,
    klLossComponent: last.klLoss,
    lossHistory,
    paddingMaskVerified: last.totalLoss < first.totalLoss,
    isDemoToyCorpus: true,
  };
}

export interface ProfessorAssignmentMatch {
  professor: ProfessorConfig;
  score: number;
  confidencePct: number;
  matchedKeywords: string[];
}

export function autoDetectBestProfessorForDocument(
  title: string,
  rawText: string,
  professors: ProfessorConfig[]
): {
  bestMatch: ProfessorAssignmentMatch;
  allRankings: ProfessorAssignmentMatch[];
} {
  const combinedTokens = normalizeAndTokenize(`${title} ${rawText.slice(0, 4000)}`);
  const tokenSet = new Set(combinedTokens);

  const rankings: ProfessorAssignmentMatch[] = professors.map((prof) => {
    let score = 0;
    const matchedKeywords: string[] = [];

    const profKeywords = prof.keywords.map((k) =>
      k
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
    );

    // Keyword matches
    for (const kw of profKeywords) {
      if (tokenSet.has(kw)) {
        score += 3.5;
        matchedKeywords.push(kw);
      } else {
        // partial stem match
        const stem = kw.slice(0, Math.min(kw.length, 5));
        if (stem.length >= 4) {
          for (const token of combinedTokens) {
            if (token.startsWith(stem) || stem.startsWith(token.slice(0, 5))) {
              score += 1.8;
              if (!matchedKeywords.includes(kw)) {
                matchedKeywords.push(kw);
              }
              break;
            }
          }
        }
      }
    }

    // Check title and discipline tokens
    const disciplineTokens = normalizeAndTokenize(`${prof.nom_affiche} ${prof.titre} ${prof.discipline_courte}`);
    for (const dt of disciplineTokens) {
      if (tokenSet.has(dt)) {
        score += 4.0;
        if (!matchedKeywords.includes(dt)) {
          matchedKeywords.push(dt);
        }
      }
    }

    return {
      professor: prof,
      score: Math.round(score * 10) / 10,
      confidencePct: 0, // will compute after normalization
      matchedKeywords: matchedKeywords.slice(0, 5),
    };
  });

  rankings.sort((a, b) => b.score - a.score);

  const maxScore = Math.max(rankings[0]?.score || 1, 1);
  rankings.forEach((r) => {
    // scale to confidence percentage
    r.confidencePct = Math.min(99, Math.max(12, Math.round((r.score / maxScore) * 88) + 10));
  });

  return {
    bestMatch: rankings[0] || {
      professor: professors[0],
      score: 1,
      confidencePct: 50,
      matchedKeywords: [],
    },
    allRankings: rankings,
  };
}
