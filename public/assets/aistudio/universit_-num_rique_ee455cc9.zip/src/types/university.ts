// © 2026 Tarik Badri & Larbi Badri — Université Numérique (NeuroDistill)
// Référence scientifique : Mghabbar & Ratnamogan (ECAI 2020)

export type SupportedLanguage = 'fr' | 'ar' | 'en';
export type LearnerLevel = 'debutant' | 'intermediaire' | 'expert';
export type UserProfilePreset = 'standard' | 'jeune' | 'senior';

export interface DocumentChunk {
  id: string;
  documentId: string;
  documentTitle: string;
  professorId: string;
  pageNumber: number;
  content: string;
  tokens: string[];
  language: SupportedLanguage;
  createdAt: string;
  sanitizedInjectionDetected?: boolean;
}

export interface LibraryDocument {
  id: string;
  professorId: string;
  title: string;
  authorOrSource: string;
  language: SupportedLanguage;
  addedAt: string;
  pageCount: number;
  sourceType: 'native_pdf' | 'ocr_scan' | 'handwritten_notes' | 'markdown_upload';
  ocrProcessingMs: number;
  rawText: string;
  chunks: DocumentChunk[];
  sanitizedWarnings: string[];
}

export interface ProfessorConfig {
  id: string;
  nom_affiche: string;
  titre: string;
  discipline_courte: string;
  avatar_initials: string;
  langues: SupportedLanguage[];
  description_simple: string;
  system_prompt: string;
  ton: string;
  niveau_par_defaut: LearnerLevel;
  bibliotheque: string;
  modele_teacher: string;
  outils_autorises: string[];
  avertissement: string;
  sujets_hors_perimetre: string[];
  keywords: string[];
  yaml_raw: string;
}

export interface CitedSource {
  documentId: string;
  documentTitle: string;
  professorName: string;
  professorId: string;
  pageNumber: number;
  excerpt: string;
  relevanceScore: number;
}

export interface ProfessorContribution {
  professorId: string;
  professorName: string;
  professorTitle: string;
  domainScore: number;
  answerSimple: string;
  answerDetailed: string;
  knownInLibrary: boolean;
  citations: CitedSource[];
  disclaimer?: string;
}

export interface ConsultationResponse {
  id: string;
  question: string;
  timestamp: string;
  measuredLatencyMs: number;
  isTransdisciplinary: boolean;
  selectedProfessors: ProfessorContribution[];
  synthesizedAnswerSimple: string;
  synthesizedAnswerDetailed: string;
  allCitations: CitedSource[];
  emergencyTriggered: boolean;
  emergencyMessage?: string;
  outOfScopeRedirect?: {
    fromProfessor: string;
    suggestedProfessorId: string;
    suggestedProfessorName: string;
  };
}

export interface CaseStudyStep {
  stepNumber: number;
  discipline: string;
  professorId: string;
  professorName: string;
  subQuestion: string;
  actionableAdvice: string;
  sourceCitation: string;
}

export interface CaseStudyResult {
  id: string;
  scenarioTitle: string;
  userDescription: string;
  measuredLatencyMs: number;
  steps: CaseStudyStep[];
  transdisciplinarySummary: string;
}

export interface QuizQuestion {
  id: string;
  professorId: string;
  professorName: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  sourceCitation: string;
}

export interface LearnerProgress {
  questionsAsked: number;
  documentsFedToAgents: number;
  pagesIndexedViaOcr: number;
  quizzesCompleted: number;
  quizScoreTotal: number;
  levelByProfessor: Record<string, LearnerLevel>;
  recentTopics: string[];
}

export interface DistillationRunResult {
  alpha: number;
  temperature: number;
  labelSmoothing: number;
  epochs: number;
  batchSize: number;
  measuredExecutionMs: number;
  initialLoss: number;
  finalLoss: number;
  ceLossComponent: number;
  klLossComponent: number;
  lossHistory: { step: number; totalLoss: number; ceLoss: number; klLoss: number }[];
  paddingMaskVerified: boolean;
  isDemoToyCorpus: boolean;
}
